package daoGestionCitas;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import clases.tCita;
import clases.tLista;

public class FachadaDAOGestionCitasImpl implements IFachadaDAOGestionCitas{

	private DAOGestionCitasImpl iDAOGestionCitas;
	
	public FachadaDAOGestionCitasImpl(DAOGestionCitasImpl DAOGestionCitas) {
		super();
		this.iDAOGestionCitas = DAOGestionCitas;
	}
	/**
	 * @param cita la cita a eliminar
	 * @return boolean 
	 */
	@Override
	public boolean EliminarCita(tCita cita) {
		return this.iDAOGestionCitas.EliminarCita(cita);
	}
	/**
	 * @param cita la cita a obtener
	 * @return tCita 
	 */
	@Override
	public tCita ObtenerCita(int idCita) {
		return this.iDAOGestionCitas.ObtenerCita(idCita);
	}
	/**
	 * @param cita la cita a anadir
	 * @return boolean
	 */
	@Override
	public boolean AnadirCita(tCita cita) {
		return this.iDAOGestionCitas.AnadirCita(cita);
	}
	/**
	 * @param fecha fecha de las citas a obtener
	 * @return tLista<tCita>
	 */
	@Override
	public tLista<tCita> ObtenListaCitas(String fecha) {
		return this.iDAOGestionCitas.ObtenListaCitas(fecha);
	}
	/**
	 * @param cita cita a verificar
	 * @return boolean
	 */
	@Override
	public boolean ExisteCita(tCita cita) {
		return this.iDAOGestionCitas.ExisteCita(cita);
	}
	/**
	 * @param cita cita a modificar
	 * @return boolean
	 */
	@Override
	public boolean ModificarCita(tCita cita) {
		return this.iDAOGestionCitas.ModificarCita(cita);
	}
	
	
}
