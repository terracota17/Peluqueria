package daoGestionCitas;


import clases.tCita;
import clases.tLista;


public interface IDAOGestionCitas {

	public boolean EliminarCita(tCita cita);
	public tLista<tCita> ObtenListaCitas(String fecha);
	public boolean AnadirCita(tCita cita);
	public boolean ExisteCita(tCita cita);
	public boolean ModificarCita(tCita cita);
	public tCita ObtenerCita(int id);
	
}
