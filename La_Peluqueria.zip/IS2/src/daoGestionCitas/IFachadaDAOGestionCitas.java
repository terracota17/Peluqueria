package daoGestionCitas;


import clases.tCita;
import clases.tLista;

public interface IFachadaDAOGestionCitas {

	public boolean EliminarCita(tCita cita);
	public tCita ObtenerCita(int idCita);
	public boolean AnadirCita(tCita cita);
	public tLista<tCita> ObtenListaCitas(String fecha);
	public boolean ExisteCita(tCita cita);
	public boolean ModificarCita(tCita cita);
	
}
