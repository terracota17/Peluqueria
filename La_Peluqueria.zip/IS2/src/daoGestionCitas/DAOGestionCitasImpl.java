package daoGestionCitas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import clases.tCita;
import clases.tLista;


public class DAOGestionCitasImpl implements IDAOGestionCitas {

	private String bd = "datosCitas.txt";
	private FileWriter fichero;
	private File file = null;
	
	public DAOGestionCitasImpl(){
		super();
		try {
			this.fichero = new FileWriter(bd);
		}catch (IOException e) {
			e.printStackTrace();
		}
		this.file = new File(bd);
	}
	
	
	/**
	 * @param cita cita a eliminar
	 * @return boolean
	 */
	@Override
	public boolean EliminarCita(tCita cita) {
		boolean eliminado = false;
		 try {

			 tLista<tCita> lista = new tLista<tCita>();
			  File inputFile = new File("datosCitas.txt");
				BufferedReader reader = new BufferedReader(new FileReader(inputFile));
				int index = -1;
				String currentLine = "";
				tCita citaAnt = null;
				int i = 0;
				String[] arrayC = {" "," "," "};
				while((currentLine = reader.readLine()) != null) {
					arrayC = currentLine.split(",");
					citaAnt = new tCita(Integer.valueOf(arrayC[0].trim()),
							arrayC[1].trim(),
							arrayC[2].trim());
					if(citaAnt.getIdCita() == (cita.getIdCita()))
						index = i;
					lista.getLista().add(citaAnt);
					i++;
				}
				//guardado en la lista la bbdd anterior
				 inputFile.delete();
				 //eliminar el Usuario de la lista
				
				  if(index != -1) lista.getLista().remove(index);
				  File file = new File("datosCitas.txt");
				  BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				  
				  for(tCita c: lista.getLista()) {
					  writer.write(c.toString());
					  writer.newLine();
				  }
				  writer.flush();
				  writer.close();
				  reader.close();
				  eliminado = true;

				

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return eliminado;
		
	}
	

	
	/**
	 * @param cita la cita a anadir
	 * @return boolean 
	 */
	@Override
	public boolean AnadirCita(tCita cita) {
		boolean anadido = false;
		try {
			BufferedWriter br = new BufferedWriter(fichero);
			
			// Escribimos linea a linea en el fichero
			fichero.write(cita.toString() + "\n");
			anadido =true;
			br.flush();
			//fichero.close();
		
		} catch (Exception ex) {
			System.out.println("Mensaje de la excepcion: " + ex.getMessage());
		}
		return anadido;
	}
	/**
	 * @param cita la cita a verificar
	 * @return boolean
	 */
	@Override
	public boolean ExisteCita(tCita cita) {

		boolean existe = false;
		String linea = "";
        try {
        	FileReader fe = new FileReader(bd);
        	BufferedReader br=new BufferedReader(fe);
        	String citaInfo[] = {"", "", ""};
			while ((linea= br.readLine()) !=null && !existe) {
				
				citaInfo= linea.split(",");
			    if(linea.equals(cita.toString())) {
			    	existe = true;
			    }else if(cita.getFecha() != null) {
			    	if(Integer.valueOf(citaInfo[0].trim()) == (cita.getIdCita())) {
			    		existe= true;
			    	}
			    }
			}
				
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return existe;
	}
	/**
	 * @param fecha la fecha de las citas a obtener 
	 * @return tLista<tCita>
	 */
	@Override
	public tLista<tCita> ObtenListaCitas(String fecha) {
		tLista<tCita> citaList = new tLista<tCita>();
		String linea = "";
        try {
        	BufferedReader in = new BufferedReader(new FileReader(bd));
        	String[] arrayCita = {"", "", ""};
            while ((linea= in.readLine()) != null) {
        		 arrayCita = linea.split(",");
        		if(arrayCita[2].equals(fecha)) {
        			citaList.getLista().add(new tCita(Integer.parseInt(arrayCita[0].trim()),
        					arrayCita[1].trim(), arrayCita[2].trim()));
        		 }		 
        	 }
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return citaList;
	}
	/**
	 * @param cita la cita a modificar
	 * @return boolean
	 */
	@Override
	public boolean ModificarCita(tCita cita) {
		
		boolean modificado = false;
		if(ExisteCita(cita)) {
			this.EliminarCita(cita);
			this.AnadirCita(cita);
			modificado = true;
		}
		return modificado;
	}


	/**
	 * @param id id de la cita a obtener
	 * @return tCita
	 */
	@Override
	public tCita ObtenerCita(int id) {
		tCita cita = new tCita(id);
		FileReader fe;
		try {
			fe = new FileReader(bd);
			BufferedReader br = new BufferedReader(fe);
			String linea = "";
			String[] arrayCita = {"", "", ""};
			
			while ((linea= br.readLine()) != null) {
				arrayCita = linea.split(",");
				if(Integer.parseInt(arrayCita[0].trim()) == (id)) {
					cita.setIdCita(Integer.parseInt(arrayCita[0].trim()));
					cita.setFecha(arrayCita[1].trim());
					cita.setHora((arrayCita[2].trim()));
				}
			}
			br.close();
			return cita;
			
	
		}catch(Exception e) {
			e.getMessage();
		}
		return cita;

	}

	
}