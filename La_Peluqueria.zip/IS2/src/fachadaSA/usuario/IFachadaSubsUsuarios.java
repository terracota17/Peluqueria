package fachadaSA.usuario;

import clases.tCliente;
import clases.tLista;
import clases.tUsuario;

public interface IFachadaSubsUsuarios {
	
	public boolean EliminarUsuario(tUsuario usuario);
	public boolean AnadirUsuario(tUsuario usuario);
	public tLista<tUsuario> ObtenListaUsuarios(String nombre);
	public boolean ModificarUsuario(tUsuario usuario);
	public tUsuario ObtenUsuario(int id);
}
