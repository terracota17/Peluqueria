package fachadaSA.usuario;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import clases.tCliente;
import clases.tLista;
import clases.tPeluquero;
import clases.tUsuario;

import dao.daoUsuario.IFachadaDAOUsuarios;


public class SASubsUsuarios implements ISASubsUsuarios {
	
	private IFachadaDAOUsuarios iDAOSubsUsuarios;
	private String bd = "datosUsuarios.txt";
	private FileWriter fichero;
	private File file = null;
	

	public SASubsUsuarios(IFachadaDAOUsuarios iDAOSubsUsuarios) {
		super();
		try {
			this.fichero = new FileWriter(bd);
			this.file = new File(bd);
			this.iDAOSubsUsuarios= iDAOSubsUsuarios;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Elimina el usuario de la BBDD(datosUsuarios)
	 * @param Usuario usuario a eliminar
	 * @return boolean. Si se ha eliminado correctamente de la BBDD devuelve true
	 */
	
	@Override
	public boolean EliminarUsuario(tUsuario Usuario) {
		boolean eliminado = false;
		if(this.iDAOSubsUsuarios.ExisteUsuario(Usuario)) 
			eliminado = this.iDAOSubsUsuarios.EliminarUsuario(Usuario);
		return eliminado;
	}

	/**
	 * Anade el usuario a la BBDD(datosUsuarios)
	 * @param Usuario usuario a anadir
	 * @return boolean.Si se ha anadido correctamente a la BBDD devuelve true
	 */
	
	@Override
	public boolean AnadirUsuario(tUsuario Usuario) {
		boolean anadido = false;
		if(!this.iDAOSubsUsuarios.ExisteUsuario(Usuario))
			anadido = this.iDAOSubsUsuarios.AnadirUsuario(Usuario);
	
		return anadido;
	}
	
	/**
	 * Obtiene la lista de los usuarios de la BBDD(datosUsuarios) con nombre introducido por par�metro
	 * @param nombre nombre del usuario a buscar en la BBDD
	 * @return tLista<tUsuario> .Devuelve la lista de los usuarios
	 */

	@Override
	public tLista<tUsuario> ObtenListaUsuarios(String nombre) {
		return this.iDAOSubsUsuarios.ObtenListaUsuarios(nombre);
	}
	
	/**
	 * Obtiene de la lista los usuarios de la BBDD(datosUsuarios) con nombre introducido por par�metro
	 * @param Usuario usuario a modificar
	 * @return boolean. Si el usuario se ha modificado correctamente la BBDD devuelve true
	 */

	@Override
	public boolean ModificarUsuario(tUsuario Usuario) {
		boolean modificado = false;
		if(this.iDAOSubsUsuarios.ExisteUsuario(Usuario)) {
			modificado = this.EliminarUsuario(Usuario);
			modificado = this.AnadirUsuario(Usuario);
		}
		return modificado;
		
	}
	
	/**
	 * Obtiene el usuario de la BBDD(datosUsuarios) con el id introducido por par�metro
	 * @param id id del usuario a obtener
	 * @return tUsuario Devuelve el usuario a buscar
	 */
	
	@Override
	public tUsuario ObtenUsuario(int id) {
		tUsuario user = new tUsuario(id);
		if(this.iDAOSubsUsuarios.ExisteUsuario(user)) {
			user = this.iDAOSubsUsuarios.ObtenUsuario(id);
		}
		return user;
	}




}