package fachadaSA.usuario;

import clases.tCliente;
import clases.tLista;
import clases.tUsuario;

public class FachadaSubsUsuarios implements IFachadaSubsUsuarios{
	
	private ISASubsUsuarios iSASubsUsuarios;
	
	public FachadaSubsUsuarios(ISASubsUsuarios iSASubsUsuarios) {
		super();
		this.iSASubsUsuarios=iSASubsUsuarios;
	}

	/**
	 *@param usuario. El usuario a eliminar
	 *@return boolean
	 */
	
	@Override
	public boolean EliminarUsuario(tUsuario usuario) {
		return this.iSASubsUsuarios.EliminarUsuario(usuario);
	}
	
	/**
	 *@param usuario. El usuario a anadir
	 *@return boolean
	 */
	
	@Override
	public boolean AnadirUsuario(tUsuario usuario) {
		return this.iSASubsUsuarios.AnadirUsuario(usuario);
		
	}

	/**
	 *@param nombre. El nombre de los usuarios a obtener
	 *@return tLista<tUsuario>
	 */
	
	@Override
	public tLista<tUsuario> ObtenListaUsuarios(String nombre) {
		return this.iSASubsUsuarios.ObtenListaUsuarios(nombre);
	}
	
	/**
	 *@param id. El id del usuario a obtener
	 *@return tUsuario
	 */

	@Override
	public tUsuario ObtenUsuario(int id) {
		return this.iSASubsUsuarios.ObtenUsuario(id);
	}
	
	/**
	 *@param usuario. El usuario a modificar
	 *@return boolean
	 */

	@Override
	public boolean ModificarUsuario(tUsuario usuario) {
		return this.iSASubsUsuarios.ModificarUsuario(usuario);
	}

	
}
