package fachadaSA.servicios;

import clases.tServicio;
import clases.tLista;

public class FachadaSubsServicios implements IFachadaSubsServicios{

	private ISASubServicios _ISASubServicios;
	
	public FachadaSubsServicios(ISASubServicios ISASubServicios) {
		super();
		this._ISASubServicios = ISASubServicios;
	}
	
	
	/**
	 * @param tipo la lista de servicios a obtener debe tener este tipo
	 * @return tLista<tServicio>
	 */
	@Override
	public tLista<tServicio> ObtenerListaServicios(String tipo) {
		return this._ISASubServicios.ObtenerListaServicios(tipo);
	}

	/**
	 * @param servicio servicio a eliminar
	 * @return boolean
	 */
	@Override
	public boolean EliminarServicio(tServicio servicio) {
		return this._ISASubServicios.EliminarServicio(servicio);
	}

	/**
	 * @param servicio servicio a anadir
	 * @return boolean
	 */
	@Override
	public boolean AnadirServicio(tServicio servicio) {
		return this._ISASubServicios.AnadirServicio(servicio);
	}

	/**
	 * @param id id del servicio a obtener
	 * @return tServicio
	 */
	@Override
	public tServicio ObtenerServicio(int id) {
		return this._ISASubServicios.ObtenerServicio(id);
	}

	/**
	 * @param servicio servicio a modificar
	 * @return boolean
	 */
	@Override
	public boolean ModificarServicio(tServicio servicio) {
		return this._ISASubServicios.ModificarServicio(servicio);
	}

}