package fachadaSA.servicios;

import clases.tLista;
import clases.tServicio;

public interface ISASubServicios{

	public boolean EliminarServicio(tServicio servicio);
	public boolean AnadirServicio(tServicio servicio);
	public boolean ModificarServicio(tServicio servicio);
	public tLista<tServicio> ObtenerListaServicios(String tipo);
	public tServicio ObtenerServicio(int id);
	
}
