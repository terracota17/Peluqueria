package fachadaSA.servicios;

import clases.tServicio;
import clases.tLista;

public interface IFachadaSubsServicios{

	public boolean EliminarServicio(tServicio servicio);
	public boolean AnadirServicio(tServicio servicio);
	public boolean ModificarServicio(tServicio servicio);
	public tLista<tServicio> ObtenerListaServicios(String tipo);
	public tServicio ObtenerServicio(int id);
	
	
}

