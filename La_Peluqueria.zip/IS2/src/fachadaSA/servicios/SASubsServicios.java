package fachadaSA.servicios;

import clases.tServicio;
import daoServicios.daoServicios.IFachadaDAOServicios;
import fachadaSA.productos.SASubsProductos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import clases.tLista;

public class SASubsServicios implements ISASubServicios{
	
	private IFachadaDAOServicios iDAOSubsServicios;
	
	public SASubsServicios(IFachadaDAOServicios iDAOSubsServicios2) {
		super();
		this.iDAOSubsServicios = iDAOSubsServicios2;
	}
	
	
	/**
	 * Elimina el servicio introducido por parametro
	 * 
	 * @param servicio servicio a eliminar
	 * @return boolean Si no existe el servicio devuelve false y si se ha eliminado con exito devuelve true
	 */
	@Override
	public boolean EliminarServicio(tServicio servicio) {
		boolean eliminado = false;
		if(this.iDAOSubsServicios.ExisteServicio(servicio)) {
			eliminado = this.iDAOSubsServicios.EliminarServicio(servicio);
		}
		return eliminado;
	}

	
	/**
	 * Anade el servicio introducido por parametro
	 * 
	 * @param servicio servicio a anadir
	 * @return boolean Si no existe el servicio devuelve false y si se ha anadido con exito devuelve true
	 */
	@Override
	public boolean AnadirServicio(tServicio servicio) {
		boolean anadido = false;
		if(!this.iDAOSubsServicios.ExisteServicio(servicio)){
			anadido = this.iDAOSubsServicios.AnadirServicio(servicio);
		}
		return anadido;
	}


	/**
	 * Modifica el servicio introducido por parametro
	 * 
	 * @param servicio servicio a modificar
	 * @return boolean Si no existe el servicio devuelve false y si se ha eliminado y anadido con exito devuelve true
	 */
	@Override
	public boolean ModificarServicio(tServicio servicio) {
		boolean modificado = false;
		if(this.iDAOSubsServicios.ExisteServicio(servicio)) {
			modificado = this.iDAOSubsServicios.EliminarServicio(servicio);
			modificado = this.iDAOSubsServicios.AnadirServicio(servicio);
			
		}
		return modificado;
	}

	
	/**
	 * Obtiene el servicio al que pertenece el id pasado por parametro
	 * 
	 * @param id del servicio a buscar
	 * @return tServicio devuelve el servicio que tiene el id pasado por parametro
	 */
	@Override
	public tServicio ObtenerServicio(int id) {
		
		tServicio servicio = new tServicio(id);
		if(this.iDAOSubsServicios.ExisteServicio(servicio)) {
			servicio = this.iDAOSubsServicios.ObtenServicio(id);
			
		}
		return servicio;
					
	}

	
	/**
	 * Obtiene la lista de servicios que hay en la BBDD
	 * 
	 * @param tipo 
	 * @return tLista<tServicio> devuelve la lista de servicios que tiene el tipo pasado por parametro
	 */
	@Override
	public tLista<tServicio> ObtenerListaServicios(String tipo) {
		tLista<tServicio> serviciosList = new tLista<tServicio>();
		serviciosList = this.iDAOSubsServicios.ObtenListaServicios(tipo);
		return serviciosList;
	}
		
	
}

