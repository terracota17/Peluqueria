package fachadaSA.GestionCitas;

import clases.tCita;
import clases.tLista;

public interface ISASubsGestionCitas {
	
	public tCita ObtenerCita(int id);
	public boolean AnadirCita(tCita cita);
	public boolean EliminarCita(tCita cita);
	public boolean ModificarCita(tCita cita);
	public tLista<tCita> ObtenListaCitas(String fecha);
	
}
