package fachadaSA.GestionCitas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import clases.tCita;
import clases.tLista;
import dao.daoUsuario.IDAOUsuarios;
import dao.daoUsuario.IFachadaDAOUsuarios;
import daoGestionCitas.IDAOGestionCitas;
import daoGestionCitas.IFachadaDAOGestionCitas;

public class SASubsGestionCitas implements ISASubsGestionCitas{
	
	private String bd = "datosCitas.txt";
	private FileWriter fichero;
	private File file = null;
	private IFachadaDAOGestionCitas DAOGestionCitas;
	
	public SASubsGestionCitas(IFachadaDAOGestionCitas iDAOGestionCitas){
		super();
		try {
			this.DAOGestionCitas =iDAOGestionCitas;
			this.fichero = new FileWriter(bd);
		}catch (IOException e) {
			e.printStackTrace();
		}
		this.file = new File(bd);
	}
	
	/**	
	 * @param cita La cita a eliminar
	 * @return boolean Eliminado
	 */
	public boolean EliminarCita(tCita cita) {
		boolean eliminado = false;
		if(this.DAOGestionCitas.ExisteCita(cita)) {
			eliminado = this.DAOGestionCitas.EliminarCita(cita);
		}
	
		return eliminado;
		
	}
/**
 * @param cita La cita a anadir
 * @return boolean Anadida
 */
	public boolean AnadirCita(tCita cita) {
		boolean anadido = false;
		if(!this.DAOGestionCitas.ExisteCita(cita)){
			anadido =this.DAOGestionCitas.AnadirCita(cita);
		}
		return anadido;
	}
	/**
	 * @param fecha La fecha de la lista de citas a obtener
	 * @return tLista<tCita> 
	 */
	@Override
	public tLista<tCita> ObtenListaCitas(String fecha) {
		tLista<tCita> citaList = new tLista<tCita>();
		citaList = this.DAOGestionCitas.ObtenListaCitas(fecha);
		return citaList;
	}
/**
 * @param cita La cita a modificar
 * @return boolean Modificado
 */
	@Override
	public boolean ModificarCita(tCita cita) {
		boolean modificado = false;
		if(this.DAOGestionCitas.ExisteCita(cita)) {
			modificado =this.DAOGestionCitas.EliminarCita(cita);
			modificado = this.DAOGestionCitas.AnadirCita(cita);
		}
		return modificado;
	}
/**
 * @param id El id de la cita a obtener
 * @return tCita La cita obtenida
 */
	@Override
	public tCita ObtenerCita(int id) {
		tCita cita = new tCita(id);
		if(this.DAOGestionCitas.ExisteCita(cita)) {
			cita = this.DAOGestionCitas.ObtenerCita(id);
		}

		return cita;
	}


}