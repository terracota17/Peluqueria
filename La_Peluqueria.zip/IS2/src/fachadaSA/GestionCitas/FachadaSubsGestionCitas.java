package fachadaSA.GestionCitas;

import clases.tCita;
import clases.tLista;
import daoGestionCitas.DAOGestionCitasImpl;
import daoServicios.daoServicios.DAOServiciosImpl;
import fachadaSA.usuario.ISASubsUsuarios;


public class FachadaSubsGestionCitas implements IFachadaSubsGestionCitas{
	
	private  ISASubsGestionCitas iSAGestionCitas;
	
	public FachadaSubsGestionCitas(ISASubsGestionCitas iSAGestionCitas) {
		super();
		this.iSAGestionCitas = iSAGestionCitas;	
	}
	/**
	 * @return tLista<tCita> 
	 */
	@Override
	public tLista<tCita> ObtenerListaCitas(String fecha) {
		return this.iSAGestionCitas.ObtenListaCitas(fecha);

	}
/**
 * @param id El id de la cita a obtener
 * @return tCita
 */
	@Override
	public tCita ObtenerCita(int id) {
		return iSAGestionCitas.ObtenerCita(id);
	}
/**
 * @param cita La cita a anadir
 * @return boolean
 */
	@Override
	public boolean AnadirCita(tCita cita) {
		return iSAGestionCitas.AnadirCita(cita);
	}
/**
 * @param cita La cita a eliminar
 * @return boolean Eliminado
 */
	@Override
	public boolean EliminarCita(tCita cita) {
		return iSAGestionCitas.EliminarCita(cita);
	}
/**
 * @param cita La cita a modificar
 * @return boolean 
 */
	@Override
	public boolean ModificarCita(tCita cita) {
		return iSAGestionCitas.ModificarCita(cita);
	}



}
