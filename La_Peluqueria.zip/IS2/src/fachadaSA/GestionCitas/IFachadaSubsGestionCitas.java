package fachadaSA.GestionCitas;

import clases.tCita;
import clases.tLista;

public interface IFachadaSubsGestionCitas {
	
	public boolean EliminarCita(tCita cita);
	public boolean AnadirCita(tCita cita);
	public boolean ModificarCita(tCita cita);
	public tCita ObtenerCita(int id);
	public tLista<tCita> ObtenerListaCitas(String fecha);
}
