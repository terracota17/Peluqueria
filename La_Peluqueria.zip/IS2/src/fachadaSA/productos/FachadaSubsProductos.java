package fachadaSA.productos;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

import clases.tLista;
import clases.tProducto;


public class FachadaSubsProductos implements IFachadaSubsProductos{

	private SASubsProductos iSASubsProductos;
	
	public FachadaSubsProductos(SASubsProductos iSASubsProductos) {
		super();
		this.iSASubsProductos = iSASubsProductos;	
	}
	/**
	 * Elimina el producto pasado por parametro
	 * 
	 * @param producto
	 * @return boolean 
	 */
	@Override
	public boolean EliminarProducto(tProducto producto) {
		return iSASubsProductos.EliminarProducto(producto);
	}
/**
 * Obtiene la lista de productos con nombre pasado por parametro
 * @return tLista<tProducto>
 */
	@Override
	public tLista<tProducto> ObtenListaProducto(String nombre) {
		return iSASubsProductos.ObtenListaProducto(nombre);
	}
/**
 * Anade el producto
 * 
 * @param producto
 * @return boolean 
 */
	@Override
	public boolean AnadirProducto(tProducto producto) {
		return iSASubsProductos.AnadirProducto(producto);
	}
/**
 * Modifica el Producto pasado por parametro
 * 
 * @param producto
 * @return boolean 
 */
	@Override
	public boolean ModificarProducto(tProducto producto) {
		return iSASubsProductos.ModificarProducto(producto);
	}
/**
 * Obtiene el producto del codigo
 * 
 * @param codigo
 * @return tProducto
 */
	@Override
	public tProducto ObtenProducto(int codigo) {
		return iSASubsProductos.ObtenProducto(codigo);
	}
}
