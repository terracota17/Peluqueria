package fachadaSA.productos;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import clases.tLista;
import clases.tProducto;
import daoProducto.IFachadaDAOProductos;

public class SASubsProductos implements ISASubsProductos {

	private String bd = "datosProductos.txt";
	private FileWriter fichero;
	private File file = null;
	private IFachadaDAOProductos iDAOSubsProductos;
	
	public SASubsProductos(IFachadaDAOProductos iDAOSubsProductos) {
		super();
		try {
			this.iDAOSubsProductos = iDAOSubsProductos;
			this.fichero = new FileWriter(bd);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.file = (new File(bd));
	}
	/**
	 * Elimina el producto de la BBDD (datosProductos) 
	 * 
	 * @param producto producto a eliminar
	 * @return boolean Si se ha eliminado correctamente de la BBDD devuelve true
	 */
	@Override
	public boolean EliminarProducto(tProducto producto) {
		boolean eliminado = false;
		if(this.iDAOSubsProductos.ExisteProducto(producto)) {
			eliminado = this.iDAOSubsProductos.EliminarProducto(producto);
		}
		return eliminado;	
			
	}
	/**
	 * Obtiene la lista los producto de la BBDD (datosUsuarios)  con nombre introducido por parámetro
	 * 
	 * @param nombre nombre del producto a buscar en la BBDD
	 * @return tLista<tProducto> Devuelve la lista de los productos
	 * 	
	 *  */
	@Override
	public tLista<tProducto> ObtenListaProducto(String nombre) {
		return this.iDAOSubsProductos.ObtenListaProducto(nombre);
	}
	/**
	 * Anade el producto de la BBDD (datosProductos) 
	 * 
	 * @param producto producto a anadir
	 * @return boolean Si no existe el producto en la BBDD se anade 
	 */
	@Override
	public boolean AnadirProducto(tProducto producto) {
		boolean anadido = false;
		if(!this.iDAOSubsProductos.ExisteProducto(producto)) {
			anadido = this.iDAOSubsProductos.AnadirProducto(producto);
		}
		return anadido;
	}

	
	/**
	 * Obtiene el producto con el código introducido por parámetro
	 * 
	 * @param codigo producto a obtener
	 * @return tProducto Si no existe el producto en la BBDD se se obtiene el producto deseado
	 */
	@Override
	public tProducto ObtenProducto(int codigo) {
		//funciona
		tProducto producto = new tProducto(codigo);
		if(this.iDAOSubsProductos.ExisteProducto(producto)) {
			producto = this.iDAOSubsProductos.ObtenProducto(codigo);
		}
		return producto;
			
	}
	/**
	 * Modifica el producto introducido por parámetro
	 * 
	 * @param producto producto a modificar
	 * @return boolean Si no existe el producto devuelve false y si existe y si se ha eliminado y además ha anadido con éxito se devuelve true
	 */
	@Override
	public boolean ModificarProducto(tProducto producto) {
		boolean modificado = false;
		if(this.iDAOSubsProductos.ExisteProducto(producto)) {
			modificado = this.iDAOSubsProductos.EliminarProducto(producto);
			modificado = this.iDAOSubsProductos.AnadirProducto(producto);
		}
		return modificado;
	}

}
