package fachadaSA.productos;

import clases.tProducto;
import clases.tLista;

public interface IFachadaSubsProductos {
	
	public boolean EliminarProducto(tProducto producto); 
	public tProducto ObtenProducto(int codigo); 
	public boolean AnadirProducto(tProducto producto);  
	public tLista<tProducto> ObtenListaProducto(String nombre);
	public boolean ModificarProducto(tProducto producto);
}
