package clases;

public class tCliente extends tUsuario{
	
	private int telefono;
	
	public tCliente(int id,String nombre, String cont, String email, int telefono){
		super(id,nombre,cont,email);
		this.telefono=telefono;
	}
	
	public tCliente(int id) {
		super(id);
	}
	/**
	  * @return telefono El telefono del cliente.
	  * 
	  */
	public int getTelefono() {
		return this.telefono;
	}
	/**
	  * Inserta un telefono en la clase tCliente.
	  * @param telefono El nuevo telefono del cliente.
	  */
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	/**
	 * @return string El telefono del cliente.
	 */
	public String toString() {
		return super.toString() + ":"+ this.telefono;
	}
}