package clases;

public class tUsuario {
	private Integer id = null;
	private String nombre = " ";
	private String contrasena= " ";
	private String email = " ";
	
	public tUsuario() {
		
	}
	
	public tUsuario(int id , String nombre, String email,  String cont){
		this.id = id;
		this.nombre=nombre;
		this.email = email;
		this.contrasena=cont;
	}
	
	public tUsuario(int id){
		this.email = " ";
		this.contrasena=" ";
		this.nombre = " ";
		this.id = id;
	}
	
	public tUsuario(Integer id, String nombre) {
		this.id =id;
		this.nombre = nombre;
		this.email = " ";
		this.contrasena=" ";
	}
/**
 * @return id El id del usuario
 */
	public Integer getId() {
		return id;
	}
	/**
	 * 
	 * @return nombre El nombre del usuario
	 */
	public String getNombre() {
		return nombre;
	}
/**
 * 
 * @param nombre El nuevo nombre del usuario
 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

/**
 * @param contrasena La nueva contrasena del usuario
 */
	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}
/**
 * 
 * @return email El email del usuario
 */
	public String getEmail() {
		return email;
	}
/**
 * 
 * @param email El nuevo email del usuario.
 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * 
	 * @param id El nuevo id del usuario.
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return contrasena La contrasena del usuario
	 */
		public String getContrasena() {
			return contrasena;
		}
	public String toString(){
		return (this.id +":"+ this.nombre +":" +  this.email+ ":" + this.contrasena).trim();
	}
	
	
}
