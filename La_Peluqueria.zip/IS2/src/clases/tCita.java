package clases;

public class tCita {
	private Integer idCita;
	private String fecha;
	private String hora;
	
	public tCita(int id,String fecha, String hora) {
		this.idCita= id;
		this.fecha = fecha;
		this.hora = hora;
	}
	public tCita(int idCita) {
		this.idCita = idCita;
		this.fecha = "";
		this.hora ="";
	}
	
	public Integer getIdCita() {
		return idCita;
	}

	public void setIdCita(Integer idCita) {
		this.idCita = idCita;
	}

	public String getFecha() {
		return this.fecha;
	}
	
	public String getHora() {
		return this.hora;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	public void setHora(String hora) {
		this.hora = hora;
	}
	
	public String toString() {
		return this.idCita+","+this.fecha +"," + this.hora;
	}
}
