package clases;

public class tPeluquero extends tUsuario{

	private tLista<tCita> listaCitas;
	
	public tPeluquero(int id,String nombre, String cont, String email, tLista<tCita> listaCitas) {
		super(id,nombre,cont,email);
		this.listaCitas = listaCitas;
	}
		
	public String toString() {
		return super.toString() + " ";
	}

	public tLista<tCita> getListaCitas() {
		return listaCitas;
	}
	
	
}