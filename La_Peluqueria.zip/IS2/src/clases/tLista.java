package clases;

import java.util.ArrayList;
import java.util.List;

public class tLista<T extends Object>  {
	
	 private List<T> lista;
	 
	 public tLista() {
		 this.lista = new ArrayList<T>();
	 }
/**
 * 
 * @return lista
 */
	public List<T> getLista() {
		return lista;
	}
	 
	 
}
