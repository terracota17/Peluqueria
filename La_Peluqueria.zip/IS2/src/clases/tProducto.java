package clases;

public class tProducto {
	
	private Integer codigo;
	private int stock;
	private double precio;
	private String nombre;
	
	
	public tProducto() {
		this.codigo = null;
		this.nombre = "";
		this.precio = 0.0;
		this.stock = 0;
	}
	
	public tProducto(int codigo, double precio, int stock, String nombre) {
		this.codigo = codigo;
		this.stock = stock;
		this.precio = precio;
		this.nombre = nombre;
		
	}
	
	public tProducto(int codigoIdentificacion) {
		this.codigo = codigoIdentificacion;
		this.nombre = "";
		this.precio = 0.0;
		this.stock = 0;
	}
	

	/**
	 * 
	 * @return codigo El codigo del producto.
	 */
	public Integer getCodigo() {
		return codigo;
	}
/**
 * 
 * @param codigo
 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
/**
 * 
 * @return stock
 */
	public int getStock() {
		return stock;
	}
/**
 * 
 * @param stock El nuevo stock del producto
 */
	public void setStock(int stock) {
		this.stock = stock;
	}
/**
 * 
 * @return precio
 */
	public double getPrecio() {
		return precio;
	}
/**
 * 
 * @param precio El nuevo precio del producto
 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
/**
 * 
 * @return nombre El nombre del producto
 */
	public String getNombre() {
		return nombre;
	}
/**
 * 
 * @param nombre El nuevo nombre del producto
 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String toString(){
		return this.codigo+":"+ this.precio+":"+ this.stock+":"+ this.nombre;
	}
}