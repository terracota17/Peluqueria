package clases;

public class tServicio {

	private String nombre;
	private double precio;
	private String descripcion;
	private String tipo;
	private Integer id;
	
	public tServicio(int id,String nombre, double precio, String descripcion, String tipo) {
		this.nombre = nombre;
		this.precio = precio;
		this.descripcion = descripcion;
		this.tipo = tipo;
		this.id = id;
		
	}
	public tServicio(int id) {
		this.nombre = "";
		this.precio = 0.0;
		this.descripcion = "";
		this.tipo = "";
		this.id = id;
	}
	/**
	 * 
	 * @return nombre El nombre del servicio
	 */
	public String getNombre() {
		return this.nombre;
	}
	/**
	 * 
	 * @return precio El precio del servicio
	 */
	public double getPrecio() {
		return this.precio;
	}
	/**
	 * 
	 * @return descripcion La descripcion del producto
	 */
	public String getDescripcion() {
		return this.descripcion;
	}
	/**
	 * 
	 * @return tipo El tipo del servicio
	 */
	public String getTipo() {
		return this.tipo;
	}
	/**
	 * 
	 * @return id El id del servicio
	 */
	public Integer getId() {
		return this.id;
	}
	/**
	 * 
	 * @param nombre El nuevo nombre del servicio
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * 
	 * @param d El nuevo precio del servicio
	 */
	public void setPrecio(double d) {
		this.precio = d;
	}
	/**
	 * 
	 * @param descripcion La nueva descripcion del servicio
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * 
	 * @param tipo El nuevo tipo del servicio
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	/**
	 * 
	 * @param id El nuevo id del servicio
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	public String toString(){
		return this.id+":"+this.nombre + ":"+ this.precio +":"+this.descripcion +":"+ this.tipo;
	}
}
