package dao.daoUsuario;

import clases.tLista;
import clases.tUsuario;

public class FachadaDAOUsuariosImpl implements IFachadaDAOUsuarios{
	
	private DAOUsuariosImpl iDAOUsuarios;
	
	
	public FachadaDAOUsuariosImpl(DAOUsuariosImpl DAOUsuarios) {
		super();
		this.iDAOUsuarios = DAOUsuarios;
	}

	/**
	 * Elimina el usuario introducido por par�metro
	 * 
	 *@param usuario
	 *@return boolean
	 */
	
	@Override
	public boolean EliminarUsuario(tUsuario usuario) {
		return this.iDAOUsuarios.EliminarUsuario(usuario);
	}

	/**
	 * Obtiene el usuario con el id introducido por par�metro
	 * 
	 *@param id
	 *@return tUsuario
	 */
	
	@Override
	public tUsuario ObtenUsuario(int id) {
		return this.iDAOUsuarios.ObtenUsuario(id);
	}

	/**
	 * Obtiene la lista de usuarios con el nombre introducido por par�metro
	 * 
	 *@param nombre
	 *@return tLista<tUsuario>
	 */
	
	@Override
	public tLista<tUsuario> ObtenListaUsuarios(String nombre) {
		return this.iDAOUsuarios.ObtenListaUsuarios(nombre);
	}
	
	/**
	 * Anade el usuario introducido por par�metro
	 * 
	 *@param usuario
	 *@return boolean
	 */

	@Override
	public boolean AnadirUsuario(tUsuario usuario) {
		return this.iDAOUsuarios.AnadirUsuario(usuario);
	}
	
	/**
	 * Comprueba si existe el usuario introducido por par�metro
	 * 
	 *@param usuario
	 *@return boolean
	 */

	@Override
	public boolean ExisteUsuario(tUsuario usuario) {
		return this.iDAOUsuarios.ExisteUsuario(usuario);
	}
	
	/**
	 * Modifica el usuario introducido por par�metro
	 * 
	 *@param usuario
	 *@return boolean
	 */

	@Override
	public boolean ModificarUsuario(tUsuario usuario) {
		return this.iDAOUsuarios.ModificarUsuario(usuario);
	}
	
	public DAOUsuariosImpl getIDAOUsuarios() {
		return iDAOUsuarios;
	}

	
	
}

