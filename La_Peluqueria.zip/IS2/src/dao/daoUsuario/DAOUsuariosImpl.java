package dao.daoUsuario;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import clases.tCliente;
import clases.tLista;
import clases.tPeluquero;
import clases.tUsuario;

public class DAOUsuariosImpl implements IDAOUsuarios {
	
	private String bd = "datosUsuarios.txt";
	private FileWriter fichero;
	private File file = null;
	
	public DAOUsuariosImpl() {
		super();
		try {
			this.fichero = new FileWriter(bd);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.file = new File(bd);
	}
	
	/**
	 * Elimina el usuario introducido por parámetro
	 * 
	 *@param usuario
	 *@return boolean
	 */
	
	@Override
	public boolean EliminarUsuario(tUsuario usuario) {
		boolean eliminado = false;
		
		 try {
			 tLista<tUsuario> lista = new tLista<tUsuario>();
			  File inputFile = new File("datosUsuarios.txt");
				BufferedReader reader = new BufferedReader(new FileReader(inputFile));
				  int index = -1;
				//this.EliminarUsuario(usuario);
				String currentLine = "";
				tUsuario UsuarioAnt;
				int i = 0;
				String[] arrayU = {" "," "," "," "," "};
				while((currentLine = reader.readLine()) != null) {
					arrayU = currentLine.split(":");
					String[] arrayUser = {" "," "," "," "," "};
					arrayU = currentLine.split(":");
					if(arrayU.length  == 4) {
						//tPeluquero
						UsuarioAnt = new tPeluquero(Integer.valueOf(arrayU[0].trim()),
								arrayU[1].trim(),
								arrayU[2].trim(),
								arrayU[3].trim(), null);
					}else {
						//tCliente
						UsuarioAnt = new tCliente(Integer.valueOf(arrayU[0].trim()),
								arrayU[1].trim(),
								arrayU[2].trim(),
								arrayU[3].trim(),
								Integer.valueOf(arrayU[4].trim()));
					}
					

					if(UsuarioAnt.getId() == (usuario.getId()))
						index = i;
					lista.getLista().add(UsuarioAnt);
					i++;
				}
				//guardado en la lista la bbdd anterior
				 inputFile.delete();
				 //eliminar el Usuario de la lista
				
				  if(index != -1) lista.getLista().remove(index);
				  File file = new File("datosUsuarios.txt");
				  BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				  
				  for(tUsuario p: lista.getLista()) {
					  writer.write(p.toString());
					  writer.newLine();
				  }
				  writer.flush();
				  writer.close();
				  reader.close();
				  eliminado = true;

				

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	 
			return eliminado;
	}
	
	/**
	 * Obtiene el usuario con el id introducido por parámetro
	 * 
	 * @param id
	 * @return tUsuario
	 */

	@Override
	public tUsuario ObtenUsuario(int id) {
		boolean encontrado = false;
		tUsuario user = new tUsuario(id);
		tCliente cliente = new tCliente(id);
		FileReader fe;
		try {
			fe = new FileReader(bd);
			BufferedReader br = new BufferedReader(fe);
			String linea = "";
			String[] arrayUser = {"", "" , "", "", ""};
			
			if(this.ExisteUsuario(user)) {
				while ((linea= br.readLine()) != null && !encontrado) {
		    		arrayUser = linea.split(":");
	            	 if(arrayUser.length == 5) {
		    			cliente.setId(Integer.valueOf(arrayUser[0].trim()));
		    			cliente.setNombre(arrayUser[1].trim());
		    			cliente.setEmail(arrayUser[2].trim());
		    			cliente.setContrasena(arrayUser[3].trim());
		    			cliente.setTelefono(Integer.valueOf(arrayUser[4].trim()));
		    			encontrado = true;
		    			
	            	 }else {
		        		 if(Integer.valueOf(arrayUser[0]) == (id)){
			    			user.setId(Integer.valueOf(arrayUser[0].trim()));
			    			user.setNombre(arrayUser[1].trim());
			    			user.setEmail(arrayUser[2].trim());
			    			user.setContrasena(arrayUser[3].trim());
			    			encontrado = true;
			    			
		        		 }
	            	 }

		        }
				br.close();
				return user;
			}else {
				return null;
			}
			
	        
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(cliente != null) return cliente;
		else return user;

	}
	
	/**
	 * Obtiene la lista de usuarios con el nombre introducido por parámetro
	 * 
	 *@param nombre
	 *@return tLista<tUsuario>
	 */

	@Override
	public tLista<tUsuario> ObtenListaUsuarios(String nombre) {
		tLista<tUsuario> userList = new tLista<tUsuario>();
		String linea = "";
        try {
        	BufferedReader in = new BufferedReader(new FileReader(bd));
        	String[] arrayUser = {"", "", "", "", ""};
       
            while ((linea= in.readLine()) != null) {
            	 arrayUser = linea.split(":");
            	 tCliente cliente = null;
            	
            	 if(arrayUser.length == 5) {
            		
            		cliente =  new tCliente(Integer.parseInt(arrayUser[0].trim()),
                			 arrayUser[1].trim(), arrayUser[2].trim(), arrayUser[3].trim(),
                			 Integer.valueOf(arrayUser[4].trim()));
            	 }
        
    			if(!arrayUser[1].trim().equals(" ") ) {
    				if(arrayUser[1].trim().equals(nombre)) {
    					if(cliente == null) {
    						//es un usuario no un cliente
    						
    						userList.getLista().add(new tUsuario(Integer.parseInt(arrayUser[0]),arrayUser[1], arrayUser[2], arrayUser[3]));
    					}else {
    						 userList.getLista().add(cliente);
    					}
    				}
    			}

        	 }
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return userList;
	}
	/**
	 * Anade el usuario introducido por parámetro
	 * 
	 * @param usuario
	 * @return boolean
	 */

	@Override
	public boolean AnadirUsuario(tUsuario usuario) {
		
		boolean anadido = false;
		try {
			
			BufferedWriter br = new BufferedWriter(fichero);
			if(!ExisteUsuario(usuario)){
				// Escribimos linea a linea en el fichero
				fichero.write(usuario.toString().trim() + "\n");
				anadido =true;
				br.flush();
				//fichero.close();
			}
		} catch (Exception ex) {
			System.out.println("Mensaje de la excepcion: " + ex.getMessage());
		}
		return anadido;
	}
	
	/**
	 * Comprueba si existe el usuario introducido por parámetro
	 * 
	 *@param usuario
	 *@return boolean
	 */

	@Override
	public boolean ExisteUsuario(tUsuario usuario) {
		//si funciona
		boolean existe = false;
		String linea = "";
        try {
        	FileReader fe = new FileReader(bd);
        	BufferedReader br=new BufferedReader(fe);
        	String usuarioInfo[] = {"","","","",""};
			while ((linea = br.readLine()) != null && !existe) {
				usuarioInfo= linea.split(":");
			    if(linea.equals(usuario.toString())) {
			    	existe = true;
			    }else if(usuario.getId() != null) {
			    	if(Integer.valueOf(usuarioInfo[0].trim()) == (usuario.getId())) {
			    		existe= true;
			    	}
			    }
			}
				
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return existe;
	}
	
	/**
	 * Modifica el usuario  introducido por parámetro
	 * 
	 * @param usuario
	 * @return boolean
	 */
	
	@Override
	public boolean ModificarUsuario(tUsuario usuario) {
		boolean modificado = false;
		if(ExisteUsuario(usuario)) {
			modificado = this.EliminarUsuario(usuario);
			modificado = this.AnadirUsuario(usuario);
		}
		return modificado;
	}
}
