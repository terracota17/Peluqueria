package daoServicios.daoServicios;

import clases.tLista;
import clases.tServicio;

public interface IFachadaDAOServicios {
	public boolean EliminarServicio(tServicio servicio); 
	public tServicio ObtenServicio(int id); 
	public boolean AnadirServicio(tServicio servicio);  
	public boolean ExisteServicio(tServicio servicio);
	public boolean ModificarServicio(tServicio servicio);
	public tLista<tServicio> ObtenListaServicios(String tipo);
}
