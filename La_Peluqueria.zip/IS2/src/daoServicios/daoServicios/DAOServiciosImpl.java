
package daoServicios.daoServicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import clases.tLista;
import clases.tServicio;


public class DAOServiciosImpl implements IDAOServicios{

	private String bd = "datosServicios.txt";
	private FileWriter fichero;
	private File file = null;
	
	public DAOServiciosImpl() {
		super();
		try {
			this.fichero= new FileWriter(bd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.file = new File(bd);
	}
	/**
	 * @param servicio el servicio a eliminar
	 * @return boolean
	 */
	@Override
	public boolean EliminarServicio(tServicio servicio) {
		boolean eliminado = false;
		
		 try {

		 tLista<tServicio> lista = new tLista<tServicio>();
		  File inputFile = new File("datosServicios.txt");
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			  int index = -1;
			
				String currentLine = "";
				tServicio productoAnt;
				int i = 0;
				String[] arrayS = {"","","","", "",""};
				while((currentLine = reader.readLine()) != null) {
					arrayS = currentLine.trim().split(":");
	
					productoAnt = new tServicio(Integer.valueOf(arrayS[0].trim()),
							arrayS[1].trim(),
							Double.parseDouble(arrayS[2].trim()),
							arrayS[3].trim(),
							arrayS[4].trim());
					if(productoAnt.getId() == (servicio.getId()))
						index = i;
					lista.getLista().add(productoAnt);
					i++;
				}
				//guardado en la lista la bbdd anterior
				 inputFile.delete();
				 //eliminar el producto de la lista
				
				  if(index != -1) lista.getLista().remove(index);
				  File file = new File("datosServicios.txt");
				  BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				  
				  for(tServicio p: lista.getLista()) {
					  writer.write(p.toString());
					  writer.newLine();
				  }
				  writer.flush();
				  writer.close();
				  reader.close();
				  eliminado = true;
			

			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
			
			return eliminado;
	}
	/**
	 * @param id la id del servicio a obtener
	 * @return tServicio
	 */
	@Override
	public tServicio ObtenServicio(int id) {
		//funciona
				tServicio servicio = new tServicio(id);
					FileReader fe;
					try {
						fe = new FileReader(bd);
						BufferedReader br = new BufferedReader(fe);
						String linea = "";
						String[] arrayServicio = {"", "" , "", "", ""};

							while ((linea= br.readLine()) != null) {
								arrayServicio = linea.split(":");
					    		if(Integer.valueOf(arrayServicio[0].trim()) == (id)){
					    			servicio.setId((Integer.valueOf(arrayServicio[0].trim())));
					    			servicio.setNombre((arrayServicio[1].trim()));
					    			servicio.setPrecio(Double.parseDouble(arrayServicio[2].trim()));
					    			servicio.setDescripcion(arrayServicio[3].trim());
					    			servicio.setTipo(arrayServicio[4].trim());
					    			
					    		}	
					        }
							br.close();
							return servicio;
		
				        
					} catch (IOException e) {
						e.printStackTrace();
					}
					return servicio;
						
	}
	/**
	 * @param tipo el tipo de los servicios a obtener
	 * @return boolean
	 */
	@Override
	public tLista<tServicio> ObtenListaServicios(String tipo) {
		tLista<tServicio> serviciosList = new tLista<tServicio>();
		String linea = "";
        try {
        	BufferedReader in = new BufferedReader(new FileReader(bd));
        	String[] arrayS = {"", "", "", "", ""};
            while ((linea= in.readLine()) != null) {
            	arrayS  = linea.split(":");
        		if(arrayS[4].trim().equals(tipo)) {
        			serviciosList.getLista().add(new tServicio(Integer.valueOf(arrayS[0].trim()),
        					 arrayS[1].trim(),
        					 Double.parseDouble(arrayS[2].trim()),
        					 arrayS[3].trim(),
        					 arrayS[4].trim()));
        		 }
        	 }
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return serviciosList;
	}
	/**
	 * @param servicio el servicio a anadir
	 * @return boolean
	 */
	@Override
	public boolean AnadirServicio(tServicio servicio) {
		boolean anadido = false;
		try {
			
			BufferedWriter br = new BufferedWriter(fichero);
				fichero.write(servicio.toString() + "\n");
				anadido =true;
				br.flush();
			
		} catch (Exception ex) {
			System.out.println("Mensaje de la excepcion: " + ex.getMessage());
		}
		return anadido;
	}
	/**
	 * Comprueba si existe tal servicio especificado por parametro
	 * 
	 * @param servicio el servicio a verificar
	 * @return boolean
	 */
	@Override
	public boolean ExisteServicio(tServicio servicio) {
		boolean existe = false;
		String linea = "";
        try {
        	FileReader fe = new FileReader(bd);
        	BufferedReader br=new BufferedReader(fe);
        	String arrayServicio[] = {"", "", "","", ""};
        	while ((linea= br.readLine()) != null && !existe) {
        		arrayServicio= linea.split(":");
				 if(linea.equals(servicio.toString())) {
	    			existe = true;
	    		}else if(servicio.getId() != null){
			    	if(Integer.parseInt(arrayServicio[0].trim()) == (servicio.getId())) {
			    		existe= true;
			    	}	
	    		}
	        }
				
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return existe;
	}
	/**
	 * @param servicio el servicio a modificar
	 * @return boolean
	 */
	@Override
	public boolean ModificarServicio(tServicio servicio) {
		boolean modificado = false;
		if(this.ExisteServicio(servicio)) {
			modificado = this.EliminarServicio(servicio);
			modificado = this.AnadirServicio(servicio);
		}
		return modificado;
	}

	
}
