package daoServicios.daoServicios;

import clases.tLista;
import clases.tServicio;

public class FachadaDAOServiciosImpl implements IFachadaDAOServicios{

	private DAOServiciosImpl iDAOServicios;
	
	public FachadaDAOServiciosImpl(DAOServiciosImpl DAOServicios) {
		super();
		this.iDAOServicios = DAOServicios;
	}
	/**
	 * @param servicio el servicio a eliminar
	 * @return boolean
	 */
	@Override
	public boolean EliminarServicio(tServicio servicio) {
		return iDAOServicios.EliminarServicio(servicio);
	}
	/**
	 * @param id el id del servicio a obtener
	 * @return tServicio
	 */
	@Override
	public tServicio ObtenServicio(int id) {
		return this.iDAOServicios.ObtenServicio(id);
	}
	/**
	 * @param tipo el tipo de los servicios a obtener
	 * @return tLista<tServicio>
	 */
	@Override
	public tLista<tServicio> ObtenListaServicios(String tipo) {
		return this.iDAOServicios.ObtenListaServicios(tipo);
	}
	/**
	 * @param servicio el servicio a anadir
	 * @return boolean
	 */
	@Override
	public boolean AnadirServicio(tServicio servicio) {
		return this.iDAOServicios.AnadirServicio(servicio);
	}
	/**
	 * @param servicio el servicio a verificar
	 * @return boolean
	 */
	@Override
	public boolean ExisteServicio(tServicio servicio) {
		return this.iDAOServicios.ExisteServicio(servicio);
	}
	/**
	 * @param servicio el servicio a modificar
	 * @return boolean
	 */
	@Override
	public boolean ModificarServicio(tServicio servicio) {
		return this.iDAOServicios.ModificarServicio(servicio);
	}


}
