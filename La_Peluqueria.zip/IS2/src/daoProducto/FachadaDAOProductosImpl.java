package daoProducto;

import clases.tLista;
import clases.tProducto;

public class FachadaDAOProductosImpl implements IFachadaDAOProductos {
	
	private DAOProductosImpl iDAOProductos;
	
	public FachadaDAOProductosImpl(DAOProductosImpl DAOProductos) {
		super();
		this.iDAOProductos = DAOProductos;
	}
/**
 * Elimina el producto 
 * 
 * @param producto
 * @return boolean
 */
	@Override
	public boolean EliminarProducto(tProducto producto) {
		return iDAOProductos.EliminarProducto(producto);
	}

	/**
	 * Obtiene la lista de productos con nombre introducido por par�metro
	 * 	 
	 * @param nombre
	 * @return  tLista<tProducto>
	 */
	@Override
	public tLista<tProducto> ObtenListaProducto(String nombre) {
		return iDAOProductos.ObtenListaProducto(nombre);
	}
	/**
	 * Anade el  producto introducido por par�metro
	 * 	 
	 * @param producto
	 * @return boolean
	 */
	@Override
	public boolean AnadirProducto(tProducto producto) {
		return iDAOProductos.AnadirProducto(producto);
	}
	/**
	 * Comprueba si existe el producto introducido por par�metro
	 * 	 
	 * @param producto
	 * @return boolean
	 */
	@Override
	public boolean ExisteProducto(tProducto producto) {
		return iDAOProductos.ExisteProducto(producto);
	}
	/**
	 * Modifica el producto introducido por parametro
	 * 
	 * @return boolean
	 * @param producto
	 */
	@Override
	public boolean ModificarProducto(tProducto producto) {
		return iDAOProductos.ModificarProducto(producto);
	}
	/**
	 * Obtiene el producto introducido por parametro
	 * 
	 * @return tProducto
	 * @param codigo
	 */
	@Override
	public tProducto ObtenProducto(int codigo) {
		return iDAOProductos.ObtenProducto(codigo);
	}
	
}
