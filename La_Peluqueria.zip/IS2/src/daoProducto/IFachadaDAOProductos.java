package daoProducto;

import clases.tLista;
import clases.tProducto;

public interface IFachadaDAOProductos {
	
	public boolean EliminarProducto(tProducto producto); 
	public tProducto ObtenProducto(int codigo);  
	public boolean AnadirProducto(tProducto producto);  
	public boolean ExisteProducto(tProducto producto);
	public tLista<tProducto> ObtenListaProducto(String nombre);
	public boolean ModificarProducto(tProducto producto);
}
