package daoProducto;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import clases.tLista;
import clases.tProducto;

public class DAOProductosImpl implements IDAOProductos {
	
	private String bd = "datosProductos.txt";
	private FileWriter fichero;
	private File file = null;
	
	public DAOProductosImpl() {
		super();
		try {
			this.fichero = new FileWriter(bd);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.file = new File(bd);
	}
	/**
	 * Elimina el producto introducido por parametro
	 * 
	 * @return boolean
	 * @param producto
	 */
	@Override
	public boolean EliminarProducto(tProducto producto) {
		boolean eliminado = false;
		
		 try {

		 tLista<tProducto> lista = new tLista<tProducto>();
		  File inputFile = new File("datosProductos.txt");
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			  int index = -1;
			
				String currentLine = "";
				tProducto productoAnt;
				int i = 0;
				String[] arrayP = {"","","",""};
				while((currentLine = reader.readLine()) != null) {
					arrayP = currentLine.trim().split(":");
					productoAnt = new tProducto(Integer.valueOf(arrayP[0].trim()),
							Double.parseDouble(arrayP[1].trim()),
							Integer.valueOf(arrayP[2].trim()),
							arrayP[3].trim());
					if(productoAnt.getCodigo() == (producto.getCodigo()))
						index = i;
					lista.getLista().add(productoAnt);
					i++;
				}
				//guardado en la lista la bbdd anterior
				 inputFile.delete();
				 //eliminar el producto de la lista
				
				  if(index != -1) lista.getLista().remove(index);
				  File file = new File("datosProductos.txt");
				  BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				  
				  for(tProducto p: lista.getLista()) {
					  writer.write(p.toString());
					  writer.newLine();
				  }
				  writer.flush();
				  writer.close();
				  reader.close();
				  eliminado = true;
			

			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
			
			return eliminado;
	}
	/**
	 * Obtiene la lista de productos con el nombre introducido por parámetro 
	 * 
	 * @return tLista<tProducto>
	 * @param nombre
	 */
	@Override
	public tLista<tProducto> ObtenListaProducto(String nombre) {
		tLista<tProducto> productList = new tLista<tProducto>();
		String linea = "";
        try {
        	BufferedReader in = new BufferedReader(new FileReader(bd));
        	String[] arrayP = {"", "", "", ""};
            while ((linea= in.readLine()) != null) {
            	arrayP  = linea.split(":");
        		if(arrayP[3].equals(nombre)) {
        			productList.getLista().add(new tProducto(Integer.valueOf(arrayP[0].trim()),
        					 Double.parseDouble(arrayP[1].trim()),
        					 Integer.parseInt(arrayP[2].trim()), arrayP[3].trim()));
        		 }
        	 }
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return productList;
	}
	/**
	 * Anade el producto introducido por parámetro 
	 * 
	 * @return boolean
	 * @param producto
	 */
	@Override
	public boolean AnadirProducto(tProducto producto) {
		boolean anadido = false;
		try {
			BufferedWriter br = new BufferedWriter(fichero);
			// Escribimos linea a linea en el fichero
			fichero.write(producto.toString() + "\n");
			anadido =true;
			br.flush();
			//fichero.close();

		} catch (Exception ex) {
			System.out.println("Mensaje de la excepci�n: " + ex.getMessage());
		}
		return anadido;
	}
	/**
	 * Comprueba si existe el producto introducido por parámetro 
	 * 
	 * @return boolean
	 * @param producto
	 */
	@Override
	public  boolean ExisteProducto(tProducto producto) {
		boolean existe = false;
		String linea = "";
        try {
        	FileReader fe = new FileReader(bd);
        	BufferedReader br=new BufferedReader(fe);
        	String arrayProducto[] = {"", "", "",""};
        	while ((linea= br.readLine()) != null && !existe) {
				arrayProducto = linea.split(":");
				 if(linea.equals(producto.toString())) {
	    			existe = true;
	    		}else if(producto.getCodigo() != null){
			    	if(Integer.parseInt(arrayProducto[0].trim()) == (producto.getCodigo())) {
			    		existe= true;
			    	}	
	    		}
	        }
				
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return existe;
	}

	/**
	 * Obtiene el producto con el codigo introducido por parámetro 
	 * 
	 * @return tProducto
	 * @param codigo
	 */
	@Override
	public tProducto ObtenProducto(int codigo) {
		//funciona
		tProducto producto = new tProducto();
			FileReader fe;
			try {
				fe = new FileReader(bd);
				BufferedReader br = new BufferedReader(fe);
				String linea = "";
				String[] arrayProducto = {"", "" , "", ""};
				tProducto p = new tProducto(codigo);
				
				while ((linea= br.readLine()) != null) {
					arrayProducto = linea.split(":");
		    		if(Integer.valueOf(arrayProducto[0].trim()) == (codigo)){
		    			producto.setCodigo((Integer.valueOf(arrayProducto[0].trim())));
		    			producto.setPrecio(Double.parseDouble(arrayProducto[1].trim()));
		    			producto.setStock(Integer.valueOf(arrayProducto[2].trim()));
		    			producto.setNombre(arrayProducto[3].trim());
		    		}	
		        }
				br.close();
				return producto;
			} catch (IOException e) {
				e.printStackTrace();
			}
			return producto;
				
	}
	/**
	 * Modifica el producto introducido por parámetro 
	 * 
	 * @return boolean
	 * @param producto
	 */
	@Override
	public boolean ModificarProducto(tProducto producto) {
		boolean modificado = false;
		if(this.ExisteProducto(producto)) {
			tProducto p = this.ObtenProducto(producto.getCodigo());
			this.EliminarProducto(p);
			this.AnadirProducto(producto);
			modificado = true;
		}
		return modificado;
	}
	
}
