package view.producto;

import java.lang.reflect.InvocationTargetException;
import javax.swing.SwingUtilities;
import dao.daoUsuario.DAOUsuariosImpl;
import dao.daoUsuario.FachadaDAOUsuariosImpl;
import dao.daoUsuario.IFachadaDAOUsuarios;
import fachadaSA.usuario.FachadaSubsUsuarios;
import fachadaSA.usuario.SASubsUsuarios;



public class Main {
		
	public static void main(String[] args) {
		
		
	
		/**
		 * Se crea la ventana principal y se ejecuta la GUI
		 */
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				@Override
				public void run() {
					MainWindow mainWindow = new MainWindow();
				}
			});
		} catch (InvocationTargetException | InterruptedException e) {
			e.printStackTrace();
		}
		
	}
}

