package view.producto;

import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

import dao.daoUsuario.DAOUsuariosImpl;
import dao.daoUsuario.FachadaDAOUsuariosImpl;
import daoGestionCitas.DAOGestionCitasImpl;
import daoGestionCitas.FachadaDAOGestionCitasImpl;
import daoProducto.DAOProductosImpl;
import daoProducto.FachadaDAOProductosImpl;
import daoServicios.daoServicios.DAOServiciosImpl;
import daoServicios.daoServicios.FachadaDAOServiciosImpl;
import fachadaSA.GestionCitas.FachadaSubsGestionCitas;
import fachadaSA.GestionCitas.SASubsGestionCitas;
import fachadaSA.productos.FachadaSubsProductos;
import fachadaSA.productos.SASubsProductos;
import fachadaSA.servicios.FachadaSubsServicios;
import fachadaSA.servicios.SASubsServicios;
import fachadaSA.usuario.FachadaSubsUsuarios;
import fachadaSA.usuario.SASubsUsuarios;



public class MainWindow extends JFrame {

	
	private PanelMainUsuarios  panelMainUsuarios;
	private PanelMainServicios panelMainServicios;
	private PanelMainProductos panelMainProductos;
	private PanelMainGestionCitas panelMainGestionCitas;
	
	private JPanel oo = new PanelMainUsuarios(new ControladorUsuarios(new FachadaSubsUsuarios(new SASubsUsuarios(new FachadaDAOUsuariosImpl(new DAOUsuariosImpl())))));
	private JPanel centerPanel;
	private ControlPanel ctrlPanel;
	
	public MainWindow() {
		super("PELUQUERIA");
		init_gui();
	}
	/**
	 * Se crea e iniciliza la ventana Principal
	 */
	public void init_gui() {

		panelMainUsuarios= new PanelMainUsuarios(new ControladorUsuarios(new FachadaSubsUsuarios(new SASubsUsuarios(new FachadaDAOUsuariosImpl(new DAOUsuariosImpl())))));
		panelMainServicios= new PanelMainServicios(new ControladorServicios(new FachadaSubsServicios(new SASubsServicios(new FachadaDAOServiciosImpl(new DAOServiciosImpl())))));
		panelMainGestionCitas = new PanelMainGestionCitas(new ControladorGestionCitas(new FachadaSubsGestionCitas(new SASubsGestionCitas(new FachadaDAOGestionCitasImpl(new DAOGestionCitasImpl())))));
		panelMainProductos=new PanelMainProductos(new ControladorProductos(new FachadaSubsProductos(new SASubsProductos(new FachadaDAOProductosImpl(new DAOProductosImpl())))));
		JPanel mainPanel = new JPanel(new BorderLayout());
		setContentPane(mainPanel);
		

		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
		centerPanel.add(oo);
		mainPanel.add(centerPanel,BorderLayout.CENTER);
		
		ctrlPanel = new ControlPanel(this);
		
		mainPanel.add(ctrlPanel,BorderLayout.PAGE_START);

		centerPanel.add(oo);

		this.setVisible(true);
		this.pack();
	}
	/**
	 * 
	 * @return oo
	 */
	public JPanel getOo() {
		return oo;
	}
	/**
	 * 
	 * @return centerPanel
	 */
	public JPanel getCenterPanel() {
		return centerPanel;
	}
	/**
	 * 
	 * @param centerPanel
	 */
	public void setCenterPanel(JPanel centerPanel) {
		this.centerPanel = centerPanel;
	}
	/**
	 * 
	 * @param oo
	 */
	public void setOo(JPanel oo) {
		this.oo = oo;
	}
	
	

}

