package view.producto;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JToolBar;

import dao.daoUsuario.DAOUsuariosImpl;
import dao.daoUsuario.FachadaDAOUsuariosImpl;
import daoGestionCitas.DAOGestionCitasImpl;
import daoGestionCitas.FachadaDAOGestionCitasImpl;
import daoProducto.DAOProductosImpl;
import daoProducto.FachadaDAOProductosImpl;
import daoServicios.daoServicios.DAOServiciosImpl;
import daoServicios.daoServicios.FachadaDAOServiciosImpl;
import fachadaSA.GestionCitas.FachadaSubsGestionCitas;
import fachadaSA.GestionCitas.SASubsGestionCitas;
import fachadaSA.productos.FachadaSubsProductos;
import fachadaSA.productos.SASubsProductos;
import fachadaSA.servicios.FachadaSubsServicios;
import fachadaSA.servicios.SASubsServicios;
import fachadaSA.usuario.FachadaSubsUsuarios;
import fachadaSA.usuario.SASubsUsuarios;

public class ControlPanel extends JPanel implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton botonProductos;
	private JButton botonCitas;
	private JButton botonUsuarios;
	private JButton botonServicios;
    private JButton botonExit;

    private JToolBar toolBar;
    public JPanel pan;
    public MainWindow man;
    private PanelMainProductos hh;

	ControlPanel(MainWindow mainWindow) {
		super();
		man = mainWindow;
		initGUI();   
		
    }
/**
 * Se crea e inicializa el Control Panel
 */
	 private void initGUI() {
         toolBar = new JToolBar();         
         toolBar.setFloatable(false);
         this.add(toolBar, BorderLayout.PAGE_START);
       
        botonSubProductos();
 		toolBar.addSeparator();
 		botonSubUsuarios();
 		toolBar.addSeparator();
 		botonSubCitas();
 		
 		toolBar.addSeparator();

 		botonSubServicios();
 		
 		toolBar.add(Box.createHorizontalGlue());
 		toolBar.addSeparator();
 		botonSalir();
    }
    /**
     * Se crea e inicializa el boton "Productos"
     */
	private void botonSubProductos() {
		botonProductos=new JButton("PRODUCTOS");
		botonProductos.setToolTipText("Subsistema de productos");
		botonProductos.setBackground(Color.orange);

		botonProductos.addActionListener(this);
		toolBar.add(botonProductos);
	}
	 /**
     * Se crea e inicializa el boton "CITAS"
     */
	private void botonSubCitas() {
		botonCitas=new JButton("CITAS");
		botonCitas.setToolTipText("Subsistema de citas");
		botonCitas.setBackground(Color.green);
		botonCitas.addActionListener(this);
		toolBar.add(botonCitas);
	}
	/**
     * Se crea e inicializa el botoon "USUARIOS"
     */
	private void botonSubUsuarios() {
		botonUsuarios=new JButton("USUARIOS");
		botonUsuarios.setToolTipText("Subsistema de usuarios");
		botonUsuarios.setBackground(Color.pink);

		botonUsuarios.addActionListener(this);
		toolBar.add(botonUsuarios);
	}
	/**
     * Se crea e inicializa el boton "SERVICIOS"
     */
	private void botonSubServicios() {
		botonServicios=new JButton("SERVICIOS");
		botonServicios.setToolTipText("Subsistema de servicios");
		botonServicios.setBackground(Color.cyan);
		botonServicios.addActionListener(this);
		toolBar.add(botonServicios);
	}/**
     * Se crea e inicializa el boton "SALIR"
     */
	private void botonSalir() {
		botonExit=new JButton("SALIR");
		botonExit.setToolTipText("Subsistema de servicios");
		botonExit.setBackground(Color.red);

		botonExit.addActionListener(this);
		toolBar.add(botonExit);
	}
	/**
	 * Se encarga de gestionar los action performed de los botones del Control Panel entre ellos estas:"Citas", "Productos", "Usuarios", "Servicio" y "Salir"
	 * @param e ActionEvent
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.botonProductos) {
			PanelMainProductos panel = new PanelMainProductos(new ControladorProductos(new FachadaSubsProductos(new SASubsProductos(new FachadaDAOProductosImpl(new DAOProductosImpl())))));
			man.getCenterPanel().removeAll();
			man.setOo(panel);
			man.init_gui();
			man.pack();
			
		}else if(e.getSource() == this.botonServicios) {
			PanelMainServicios panel = new PanelMainServicios(new ControladorServicios(new FachadaSubsServicios(new SASubsServicios(new FachadaDAOServiciosImpl(new DAOServiciosImpl())))));
			man.getCenterPanel().removeAll();
			man.setOo(panel);
			man.init_gui();
			man.pack();
		}else if(e.getSource() == this.botonCitas) {
			PanelMainGestionCitas panel = new PanelMainGestionCitas(new ControladorGestionCitas(new FachadaSubsGestionCitas(new SASubsGestionCitas(new FachadaDAOGestionCitasImpl(new DAOGestionCitasImpl())))));
			man.getCenterPanel().removeAll();
			man.setOo(panel);
			man.init_gui();
			man.pack();
		}else if(e.getSource() == this.botonUsuarios) {
			PanelMainUsuarios panel = new PanelMainUsuarios(new ControladorUsuarios(new FachadaSubsUsuarios(new SASubsUsuarios(new FachadaDAOUsuariosImpl(new DAOUsuariosImpl())))));
			man.getCenterPanel().removeAll();
			man.setOo(panel);
			man.init_gui();
			man.pack();
		}else if(e.getSource() == this.botonExit) System.exit(0);
		
	}
}
