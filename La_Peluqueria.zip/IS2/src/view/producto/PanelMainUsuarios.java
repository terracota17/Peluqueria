package view.producto;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import clases.tLista;
import clases.tProducto;
import clases.tUsuario;
import dao.daoUsuario.DAOUsuariosImpl;
import dao.daoUsuario.FachadaDAOUsuariosImpl;
import fachadaSA.usuario.FachadaSubsUsuarios;
import fachadaSA.usuario.SASubsUsuarios;

public class PanelMainUsuarios extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int estado;
	private tUsuario users[];
	
	
	private JButton Buscar;
	private JButton Anadir;
	private JButton Borrar;
	private JButton Consultar;

	private JTextField NombreT;
	private JList<tUsuario> ListaUsuarios;

    
    private JPanel centerPanel;
    private JPanel rPanel;
	private DefaultListModel<tUsuario> listModel;
	private PanelConsultaUsuarios panelC;
	private ControladorUsuarios controladorUsuarios;
	
	public PanelMainUsuarios(ControladorUsuarios controladorUsuarios) {
		this.controladorUsuarios = controladorUsuarios;
		init_gui();
		
	}
	
	/**
	 *Se crea el PanelMainUsuarios
	 */
	private void init_gui() {
		//DAOUsuariosImpl 
		controladorUsuarios=new ControladorUsuarios(new FachadaSubsUsuarios(new SASubsUsuarios(new FachadaDAOUsuariosImpl(new DAOUsuariosImpl()))));
		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
		this.add(centerPanel,BorderLayout.CENTER);
		
		rPanel = new JPanel();
		rPanel.setLayout(new BoxLayout(rPanel, BoxLayout.Y_AXIS));
		this.add(rPanel,BorderLayout.EAST);
		
		
		buscadorNombre();
		listaUsuarios();
		botonBuscar();
		botonBorrar();
		botonAnadir();
		botonconsultar();
		
	}
	
	/**
	 * Se inicializa y se crea el buscador de Usuarios
	 */
	private void buscadorNombre() {
		 NombreT=new JTextField("Introduzca el nombre");
		 
		 NombreT.setBounds(300,0,400,300);
		 NombreT.addActionListener(this);
		 
		 centerPanel.add(NombreT);
	}
	
	/**
	 * Se inicializa la lista de Usuarios y se anade al panel central de la GUI
	 */
	private void listaUsuarios() {
	    listModel = new DefaultListModel<tUsuario>();
		ListaUsuarios= new JList<tUsuario>();
		ListaUsuarios.setModel(listModel);
		ListaUsuarios.setVisible(true);
		ListaUsuarios.setBounds(0, 0, 300, 300);
		ListaUsuarios.setBackground(Color.PINK);
		ListaUsuarios.setPreferredSize(new Dimension(400, 400));
		ListaUsuarios.setForeground(Color.BLACK);
		centerPanel.add(ListaUsuarios);
		
	}
	
	/**
	 * Se inicializa y se crea el boton "Buscar" de Usuarios
	 */
	private void botonBuscar() {
		Buscar=new JButton("Buscar");
		Buscar.setToolTipText("Pulse para buscar");
		Buscar.addActionListener(this);
		rPanel.add(Buscar);
	}
	
	/**
	 * Se inicializa y se crea el boton "Borrar" de Usuarios
	 */
	private void botonBorrar() {
		Borrar=new JButton("Borrar");
		Borrar.setToolTipText("Pulse para buscar");
		Borrar.addActionListener(this);
		rPanel.add(Borrar);
	}
	
	/**
	 * Se inicializa y se crea el boton "Anadir" de Usuarios
	 */
	private void botonAnadir() {
		Anadir=new JButton("Anadir");
		Anadir.setToolTipText("Pulse para Anadir");
		Anadir.addActionListener(this);
		rPanel.add(Anadir);
		
	}
	
	/**
	 * Se inicializa y se crea el boton "Consultar" de Usuarios
	 */
	private void botonconsultar() {
		Consultar=new JButton("Consultar");
		Anadir.setToolTipText("Pulse para Consultar");
		Consultar.addActionListener(this);
		rPanel.add(Consultar);
	}
	
	/**
	 * Se encarga de los action performed de los botones "Anadir", "Consultar", "Buscar", "Borrar".
	 * El bot�n "Anadir" se encargar� de crear el dialogo con los respectivos cambios para anadir el Usuario.
	 * El bot�n "Consultar" se encargar� de crear un dialogo para modificar el Usuario.
	 * El bot�n "Buscar" se encargar� de buscar en la BBDD todos los registros con nombre introducido por parametros.
	 * El bot�n "Borrar" se encargar� de eliminar el Usuario elegido. 
	 * 
	 * Se lanza un mensaje para informar de si ha habido errores durante la ejecuci�n del proyecto.
	 * 
	 * @param e ActionEvent
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.Buscar) {
		
			String str=NombreT.getText().trim();
			tLista<tUsuario> lista;
			lista = controladorUsuarios.getFachadaUsuarios().ObtenListaUsuarios(str);
			users=new tUsuario[lista.getLista().size()];
			if(!lista.getLista().isEmpty()) {
				for(int i = 0; i<lista.getLista().size();i++) {
					users[i]= lista.getLista().get(i);
				}
				ListaUsuarios.setListData(users);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha encontrado ningun usuario con nombre: " + "\"" + str + "\"",  "",
						 JOptionPane.CANCEL_OPTION);
			}
		}
		else if(e.getSource() == this.Anadir) {
			estado=1;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			panelC = new PanelConsultaUsuarios(estado, this.controladorUsuarios, this.ListaUsuarios);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 490, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			dialogU.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		}else if(e.getSource() == this.Consultar) {
			estado=0;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			PanelConsultaUsuarios panelC = new  PanelConsultaUsuarios(estado, this.controladorUsuarios, this.ListaUsuarios);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 490, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			
			
		}else if(e.getSource() == this.Borrar) {
			//mostrar lista
			ListaUsuarios.repaint();
			tUsuario usuarioAEliminar;
			int index = this.ListaUsuarios.getSelectedIndex();
			usuarioAEliminar = this.controladorUsuarios.getFachadaUsuarios().ObtenUsuario(index+1);
			boolean eliminado = this.controladorUsuarios.getFachadaUsuarios().EliminarUsuario(usuarioAEliminar);
			this.listModel.removeElement(usuarioAEliminar);
			this.ListaUsuarios.repaint();
			if(eliminado) {
				panelC.restarId();
				this.ListaUsuarios.repaint();
				JOptionPane.showMessageDialog(this,
						 "Se ha eliminado correctamente el usuario ", "",
						 JOptionPane.CANCEL_OPTION);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha podido eliminar el usuario ", "",
						 JOptionPane.CANCEL_OPTION);
			}
		}
	}
}

