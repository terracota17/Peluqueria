package view.producto;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import clases.tCita;
import clases.tCliente;
import clases.tUsuario;

public class PanelConsultaCitas extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private int estado;
	private static final long serialVersionUID = 1L;
	private JButton Modificar;
	private JButton Volver;
	private JLabel Hora;
	private JLabel Fecha;
	

	private JTextField HoraT;
	private JTextField FechaT;
	
	
	private JList<tCita> listaCitas;
	private ControladorGestionCitas controladorCitas;
	
	private static int id=1;
	
	
	public PanelConsultaCitas(int estado,ControladorGestionCitas controladorCitas, JList<tCita> listaCitas) {
		this.estado=estado;
		this.listaCitas = listaCitas;
		this.controladorCitas = controladorCitas; 

		init_gui();
	}
	/**
	 * Inicializa la gui, creando los botones y demás componentes
	 */
	private void init_gui() {
		this.setVisible(true);
		if(estado==1) Modificar = new JButton("Anadir");
		else Modificar = new JButton("Modificar");
		
		Modificar.addActionListener(this);
		Modificar.setToolTipText("Anadir cita");
		Volver = new JButton("Volver");
		Volver.addActionListener(this);
		Volver.setToolTipText("Volver a panel principal");
		Fecha = new JLabel("Fecha");
		Hora = new JLabel("Hora");
		FechaT = new JTextField("fecha");
		FechaT.setPreferredSize(new Dimension(100, 25));
		HoraT = new JTextField("hora");
		HoraT.setPreferredSize(new Dimension(100, 25));
	
		
		Volver.setPreferredSize(new Dimension(90, 30));
		Modificar.setPreferredSize(new Dimension(90, 30));
		JPanel panelVolverModificar = new JPanel();
		panelVolverModificar.setVisible(true);
		panelVolverModificar.add(Volver);
		panelVolverModificar.add(new JLabel(" "));
		panelVolverModificar.add(Modificar);
		JPanel panelBusqueda = new JPanel();
	
		panelBusqueda.setVisible(true);
	
		panelBusqueda.add(Hora);
		panelBusqueda.add(HoraT);
		
		
		
		panelBusqueda.add(Fecha);
		panelBusqueda.add(FechaT);
		
		

		
		this.setLayout(new BorderLayout());
		this.add(panelBusqueda, BorderLayout.PAGE_START);
		this.add(panelVolverModificar, BorderLayout.PAGE_END);
		
		
	}
	/**
	 * resta 1 al id
	 */
	public void restarId() {
		id--;
	}
	
	/**
	 * Se verifica cual es la acción ejecutada (presionar volver o modificar) y se 
	 * actua en consecuencia. 
	 * Se avisa de si ha habido algun error durante ejecución
	 * @param e accion ejecutada sobre el panel de citas
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.Volver) {
			//cerrrar el dialogo
			Window w= SwingUtilities.getWindowAncestor(this);
			w.setVisible(false);
			
		}else if(e.getSource() == this.Modificar) {
			if(estado==1) {
				//Anadir
				
				String fecha =  (!this.HoraT.getText().trim().equals("hora") && !this.HoraT.getText().trim().equals("") ) ? HoraT.getText().trim():"Sin hora" ;
				String hora = (!this.FechaT.getText().trim().equals("fecha") && !this.FechaT.getText().trim().equals("")) ? this.FechaT.getText().trim() :" Sin fecha";
				
				
				boolean anadido=this.controladorCitas.getfGP().AnadirCita(new tCita(id,fecha,hora));
				if(anadido) {
					id++;
					JOptionPane.showMessageDialog(null,
							 "Se ha anadido correctamente la cita", "",
							 JOptionPane.CANCEL_OPTION);
					
				}else {
					JOptionPane.showMessageDialog(null,
							 "No se ha anadido correctamente la cita", "",
							 JOptionPane.CANCEL_OPTION);
				}
			}else {
				Integer index = listaCitas.getSelectedIndex();
				String fecha =  (!this.HoraT.getText().trim().equals("hora") && !this.HoraT.getText().trim().equals("") ) ? HoraT.getText().trim():"Sin hora" ;
				String hora = (!this.FechaT.getText().trim().equals("fecha") && !this.FechaT.getText().trim().equals("")) ? this.FechaT.getText().trim() :" Sin fecha";
				boolean modificado = this.controladorCitas.getfGP().ModificarCita(new tCita(index+1,
						fecha,
						hora));
				if(modificado) {
					JOptionPane.showMessageDialog(null,
							 "Se ha modificado correctamente el usuario", "",
							 JOptionPane.CANCEL_OPTION);
					
				}
			}
			
	}
		
	}
}