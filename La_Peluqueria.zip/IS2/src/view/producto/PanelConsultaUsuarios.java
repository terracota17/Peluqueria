package view.producto;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import clases.tCliente;
import clases.tUsuario;

public class PanelConsultaUsuarios extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private int estado;
	private static final long serialVersionUID = 1L;
	private JButton Modificar;
	private JButton Volver;
	private JLabel Nombre;
	private JLabel Constrasena;
	private JLabel email;
	private JLabel telf;

	private JTextField NombreT;
	private JTextField ContrasenaT;
	private JTextField emailT;
	private JTextField telfT;
	private JList<tUsuario> listaUsuarios;
	private ControladorUsuarios controladorUsuarios;
	
	private static int id=1;
	
	
	public PanelConsultaUsuarios(int estado,ControladorUsuarios controladorUsuarios, JList<tUsuario> listaUsuarios) {
		this.estado=estado;
		this.listaUsuarios = listaUsuarios;
		this.controladorUsuarios = controladorUsuarios; 
		init_gui();
	}
	
	
	/**
	 * Se crea el panelConsultaUsuarios
	 */
	private void init_gui() {
		this.setVisible(true);
		if(estado==1) Modificar = new JButton("Anadir");
		else Modificar = new JButton("Modificar");
		
		Modificar.addActionListener(this);
		Modificar.setToolTipText("Anadir usuario");
		Volver = new JButton("Volver");
		Volver.addActionListener(this);
		Volver.setToolTipText("Volver a panel principal");
		Nombre = new JLabel("nombre");
		Constrasena = new JLabel("Contrasena");
		email = new JLabel("email");
		telf=new JLabel("telefono");
		NombreT = new JTextField("nombre");
		ContrasenaT = new JTextField("contrasena");
		telfT=new JTextField("91493582");
		emailT = new JTextField("email");
	
		
		Volver.setPreferredSize(new Dimension(90, 30));
		Modificar.setPreferredSize(new Dimension(90, 30));
		JPanel panelVolverModificar = new JPanel();
		panelVolverModificar.setVisible(true);
		panelVolverModificar.add(Volver);
		panelVolverModificar.add(new JLabel(" "));
		panelVolverModificar.add(Modificar);
		JPanel panelBusqueda = new JPanel();
	
		panelBusqueda.setVisible(true);
	
		panelBusqueda.add(Nombre);
		panelBusqueda.add(NombreT);
		
		panelBusqueda.add(email);
		panelBusqueda.add(emailT);
		
		panelBusqueda.add(Constrasena);
		panelBusqueda.add(ContrasenaT);
		
		panelBusqueda.add(telf);
		panelBusqueda.add(telfT);

		
		this.setLayout(new BorderLayout());
		this.add(panelBusqueda, BorderLayout.PAGE_START);
		this.add(panelVolverModificar, BorderLayout.PAGE_END);
		
		
	}
	
	/**
	 * Se encarga de los action listeners de los botones "Volver" y "Modificar". 
	 * El boton "Volver" cerrar� el di�logo creado por el PanelMainUsuarios. El bot�n "Modificar" se encargar� de modificar correctamente el usuario.
	 * Si alguno de los campos introducidos por el usuario son incorrectos, se lanzar� una excepcion avisando del problema.
	 * Adem�s, si ocurre alg�n error en la ejecuci�n, se lanza el mensaje de error: "No se ha modificado correctamente el usuario" si se intenta modificar y "No se ha anadido correctamente el usuario" si se intenta anadir.
	 * @param e ActionEvent
	 */
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.Volver) {
			//cerrrar el dialogo
			Window w= SwingUtilities.getWindowAncestor(this);
			w.setVisible(false);
			
		}else if(e.getSource() == this.Modificar) {
			if(estado==1) {
				//Anadir
				try {
					String nombre =  (!this.NombreT.getText().trim().equals("nombre") && !NombreT.getText().equals("") ) ? NombreT.getText().trim():"nombre" ;
					String contra = (!this.ContrasenaT.getText().trim().equals("contrasena")&& !ContrasenaT.getText().equals("") ) ? this.ContrasenaT.getText().trim() :"contrasena";
					String email = (!this.emailT.getText().trim().equals("email")&& !emailT.getText().equals("") ) ? this.emailT.getText().trim():"email";
					int telf = (!telfT.getText().equals("")) ? Integer.valueOf(this.telfT.getText().trim()):  -1;
					if(telf == -1) throw new NumberFormatException("El telefono no puede ser vacio");
					
					boolean anadido=this.controladorUsuarios.getFachadaUsuarios().AnadirUsuario(new tCliente(id,nombre,contra,email,telf));
					if(anadido) {
						id++;
						JOptionPane.showMessageDialog(null,
								 "Se ha anadido correctamente el usuario", "",
								 JOptionPane.CANCEL_OPTION);
						
					}else {
						JOptionPane.showMessageDialog(null,
								 "No se ha anadido correctamente el usuario", "",
								 JOptionPane.CANCEL_OPTION);
					}
				}catch(NumberFormatException ex ) {
					JOptionPane.showMessageDialog(null,
							 ex.getMessage(), "",
							 JOptionPane.CANCEL_OPTION); 
					JOptionPane.showMessageDialog(null,
							 "No se ha anadido correctamente el usuario", "",
							 JOptionPane.CANCEL_OPTION);
				}
				
			}else {
				try {
					Integer index = listaUsuarios.getSelectedIndex();
					String nombre =  (!this.NombreT.getText().trim().equals("nombre") && !NombreT.getText().equals("") ) ? NombreT.getText().trim():"nombre" ;
					String contra = (!this.ContrasenaT.getText().trim().equals("contrasena")&& !ContrasenaT.getText().equals("") ) ? this.ContrasenaT.getText().trim() :"contrasena";
					String email = (!this.emailT.getText().trim().equals("email")&& !emailT.getText().equals("") ) ? this.emailT.getText().trim():"email";
					int telf = (!telfT.getText().equals("") ) ? Integer.valueOf(this.telfT.getText().trim()): -1;
					if(telf == -1) throw new NumberFormatException("El telefono no puede ser vacio !!! ");
					boolean modificado = this.controladorUsuarios.getFachadaUsuarios().ModificarUsuario(new tCliente(index+1,
							nombre,
							contra,
							email,
							telf));
					if(modificado) {
						JOptionPane.showMessageDialog(null,
								 "Se ha modificado correctamente el usuario", "",
								 JOptionPane.CANCEL_OPTION);
						
					}
				}catch(NumberFormatException ex) {
					JOptionPane.showMessageDialog(null,
							 ex.getMessage(), "",
							 JOptionPane.CANCEL_OPTION); 
					JOptionPane.showMessageDialog(null,
							 "No se ha anadido correctamente el usuario", "",
							 JOptionPane.CANCEL_OPTION);
				}
				
			}
	}
		
	}
	
	
	/**
	 * Se resta 1 al id
	 */
	public void restarId() {
		 id--;
	}

}
