package view.producto;


import fachadaSA.usuario.IFachadaSubsUsuarios;

public class ControladorUsuarios {
	private IFachadaSubsUsuarios fachadaUsuarios;
	
	public ControladorUsuarios( IFachadaSubsUsuarios fachadaUsuarios) {
		this.fachadaUsuarios = fachadaUsuarios;
	}

	/** 
	 * Get de fachadaUsuarios
	 * 
	 * @return IFachadaSubsUsuarios
	 */
	public IFachadaSubsUsuarios getFachadaUsuarios() {
		return fachadaUsuarios;
	}

	/**
	 * Set de fachadaUsuarios
	 * 
	 * @param fachadaUsuarios
	 */
	public void setFachadaUsuarios(IFachadaSubsUsuarios fachadaUsuarios) {
		this.fachadaUsuarios = fachadaUsuarios;
	}
	
}
