package view.producto;

import fachadaSA.GestionCitas.IFachadaSubsGestionCitas;

public class ControladorGestionCitas {
	private IFachadaSubsGestionCitas fGP;
	
	public ControladorGestionCitas(IFachadaSubsGestionCitas fGP) {
		this.fGP = fGP;
	}

	/** 
	 * Get de fGP
	 * 
	 * @return IFachadaSubsGestionCitas
	 */
	public IFachadaSubsGestionCitas getfGP() {
		return fGP;
	}

	/**
	 * Set de fGP
	 * 
	 * @param fGP
	 */
	public void setfGP(IFachadaSubsGestionCitas fGP) {
		this.fGP = fGP;
	}
	
	
}