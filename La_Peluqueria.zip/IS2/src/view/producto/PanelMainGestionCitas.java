package view.producto;


import java.awt.BorderLayout; 
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javax.swing.JTextField;

import clases.tCita;
import clases.tLista;

import daoGestionCitas.DAOGestionCitasImpl;
import daoGestionCitas.FachadaDAOGestionCitasImpl;
import fachadaSA.GestionCitas.FachadaSubsGestionCitas;
import fachadaSA.GestionCitas.SASubsGestionCitas;



public class PanelMainGestionCitas extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int estado;
	private tCita[] citas;
	
	
	private JButton Buscar;
	private JButton Anadir;
	private JButton Borrar;
	private JButton Consultar;

	private JTextField NombreT;
	private JList<tCita> ListaCitas;
    
    private JPanel centerPanel;
    private JPanel rPanel;
	private DefaultListModel<tCita> listModel;
	private PanelConsultaCitas panelC;
	private ControladorGestionCitas controladorGestionCitas;
	
	public PanelMainGestionCitas(ControladorGestionCitas controladorCitas) {
		this.controladorGestionCitas = controladorCitas;
		init_gui();
		
	}
	/**
	 * Se crea el panelMainGestionCitas
	 */
	private void init_gui() {
		
		controladorGestionCitas=new ControladorGestionCitas(new FachadaSubsGestionCitas(new SASubsGestionCitas(new FachadaDAOGestionCitasImpl(new DAOGestionCitasImpl()))));
		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
		this.add(centerPanel,BorderLayout.CENTER);
		
		rPanel = new JPanel();
		rPanel.setLayout(new BoxLayout(rPanel, BoxLayout.Y_AXIS));
		this.add(rPanel,BorderLayout.EAST);
		
		
		buscadorNombre();
		listaCitas();
		botonBuscar();
		botonBorrar();
		botonAnadir();
		botonconsultar();
		
	}
	
	/**
	 * Se inicializa y se crea el buscador de gesti�n de citas
	 */
	private void buscadorNombre() {
		 NombreT=new JTextField("Introduzca la fecha");
		 NombreT.addActionListener(this);
	
		centerPanel.add(NombreT);
	}
	
	/**
	 * Se inicializa la lista de gesti�n de citas y se anade al panel central de la GUI
	 */
	
	private void listaCitas() {
	    listModel = new DefaultListModel<tCita>();
	    ListaCitas= new JList<tCita>();
	    ListaCitas.setModel(listModel);
	    ListaCitas.setVisible(true);
	    ListaCitas.setBounds(0, 0, 300, 300);
	    ListaCitas.setBackground(Color.PINK);
	    ListaCitas.setPreferredSize(new Dimension(400, 400));
	    ListaCitas.setForeground(Color.BLACK);
		centerPanel.add(ListaCitas);
		
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Buscar" de gesti�n de citas
	 */
	
	private void botonBuscar() {
		Buscar=new JButton("Buscar");
		Buscar.setToolTipText("Pulse para buscar");
		Buscar.addActionListener(this);
		rPanel.add(Buscar);
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Borrar" de gesti�n de citas
	 */
	
	private void botonBorrar() {
		Borrar=new JButton("Borrar");
		Borrar.setToolTipText("Pulse para buscar");
		Borrar.addActionListener(this);
		rPanel.add(Borrar);
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Anadir" de gesti�n de citas
	 */
	
	private void botonAnadir() {
		Anadir=new JButton("Anadir");
		Anadir.setToolTipText("Pulse para Anadir");
		Anadir.addActionListener(this);
		rPanel.add(Anadir);
		
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Consultar" de gesti�n de citas
	 */
	
	private void botonconsultar() {
		Consultar=new JButton("Consultar");
		Anadir.setToolTipText("Pulse para Consultar");
		Consultar.addActionListener(this);
		rPanel.add(Consultar);
	}
	
	/**
	 * Se encarga de los action listeners de los botones "Anadir", "Consultar", "Borrar" y "Buscar". 
	 * El bot�n "Anadir" se encargar� de crear el dialogo con los respectivos cambios para anadir correctamente la cita.
	 * El bot�n "Consultar" se encargar� de crear un dialogo para modificar la cita.
	 * El bot�n "Borrar" se encargar� de eliminar la cita elegida.
	 * El bot�n "Buscar" se encargar� de buscar en la BBDD todos los registros con fecha introducida.
	 * Si ocurre alg�n error en la ejecuci�n, se lanza el mensaje de error: "No se ha encontrado ninguna cita con esa fecha" si se intenta buscar y "No se ha podido eliminar la cita" si se intenta borrar.
	 * @param e ActionEvent 
	 */
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == this.Buscar) {
		
			String str=NombreT.getText().trim();
			tLista<tCita> lista;
			lista = controladorGestionCitas.getfGP().ObtenerListaCitas(str);
			citas=new tCita[lista.getLista().size()];
			if(!lista.getLista().isEmpty()) {
				for(int i = 0; i<lista.getLista().size();i++) {
					citas[i]= lista.getLista().get(i);
				}
				ListaCitas.setListData(citas);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha encontrado ninguna cita con fecha: " + "\"" + str + "\"",  "",
						 JOptionPane.CANCEL_OPTION);
			}
		}
		else if(e.getSource() == this.Anadir) {
			
			estado=1;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			panelC = new PanelConsultaCitas(estado,this.controladorGestionCitas, this.ListaCitas);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 300, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			dialogU.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			
		}else if(e.getSource() == this.Consultar) {
			
			estado=0;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			PanelConsultaCitas panelC = new  PanelConsultaCitas(estado,this.controladorGestionCitas, this.ListaCitas);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 300, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			
			
		}else if(e.getSource() == this.Borrar) {
			//mostrar lista
			ListaCitas.repaint();
			tCita citaAEliminar;
			int index = this.ListaCitas.getSelectedIndex();
			citaAEliminar = this.controladorGestionCitas.getfGP().ObtenerCita(index+1);
			boolean eliminado = this.controladorGestionCitas.getfGP().EliminarCita(citaAEliminar);
			this.listModel.removeElement(citaAEliminar);
			this.ListaCitas.repaint();
			if(eliminado) {
				panelC.restarId();
				this.ListaCitas.repaint();
				JOptionPane.showMessageDialog(this,
						 "Se ha eliminado correctamente la cita ", "",
						 JOptionPane.CANCEL_OPTION);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha podido eliminar la cita ", "",
						 JOptionPane.CANCEL_OPTION);
			}
		}
	}
}


