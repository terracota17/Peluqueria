package view.producto;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.xml.transform.Templates;

import clases.tLista;
import clases.tServicio;
import clases.tUsuario;

public class PanelMainServicios extends JPanel implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton Buscar;
	private JButton Anadir;
	private JButton Eliminar;
	private JButton Consultar;

	private JTextField TipoServicioT;
	private JList<tServicio> ListaServicios;
	private JPanel centerPanel;
    private JPanel rPanel;
    private int index= -1;
    private int estado;
    private ControladorServicios controladorServicios;
	private PanelConsultaServicios panelC;
	private DefaultListModel<tServicio> listModel;
	private tServicio servicios[];
	
	public PanelMainServicios(ControladorServicios controladorServicios) {
		this.controladorServicios = controladorServicios;
		init_gui();
	}
	
	/**
	 * Se crea el panelMainServicios
	 */
	
	private void init_gui() {
		listModel = new DefaultListModel<tServicio>();
		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
		this.add(centerPanel,BorderLayout.CENTER);
		
		rPanel = new JPanel();
		rPanel.setLayout(new BoxLayout(rPanel, BoxLayout.Y_AXIS));
		this.add(rPanel,BorderLayout.EAST);
		
		buscadorNombre();
		listaServicios();
		botonBuscar();
		botonBorrar();
		botonAnadir();
		botonconsultar();
	}
	
	/**
	 * Se inicializa y se crea el buscador de servicios
	 */
	
	private void buscadorNombre() {
		TipoServicioT=new JTextField("Introduzca el tipo de servicio");
		TipoServicioT.setToolTipText("Subsistema de productos");
		TipoServicioT.setBounds(300,0,400,300);
		TipoServicioT.addActionListener(this);
		 
		centerPanel.add(TipoServicioT);
	}
	
	/**
	 * Se inicializa la lista de servicios y se anade al panel central de la GUI
	 */
	
	private void listaServicios() {
		
		ListaServicios= new JList<tServicio>();	
		ListaServicios.setModel(listModel);
		ListaServicios.setFixedCellHeight(20);
		ListaServicios.setFixedCellWidth(200);
		ListaServicios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListaServicios.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if(ListaServicios.getValueIsAdjusting()) {
					 index = ListaServicios.getSelectedIndex();
				}
				
			}
		});
		
		ListaServicios.setPreferredSize(new Dimension(400, 400));
		ListaServicios.setBackground(Color.cyan);
		ListaServicios.setVisible(true);
		centerPanel.add(ListaServicios);
		
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Buscar" de servicios
	 */
	
	private void botonBuscar() {
		Buscar=new JButton("Buscar");
		Buscar.setToolTipText("Pulse para buscar");
		Buscar.addActionListener(this);
		Buscar.setPreferredSize(new Dimension(100, 25));
		rPanel.add(Buscar);
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Borrar" de servicios
	 */
	
	private void botonBorrar() {
		Eliminar=new JButton("Borrar");
		Eliminar.setToolTipText("Pulse para buscar");
		Eliminar.addActionListener(this);
		Eliminar.setPreferredSize(new Dimension(100, 25));
		rPanel.add(Eliminar);
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Anadir" de servicios
	 */
	
	private void botonAnadir() {
		Anadir=new JButton("Anadir");
		Anadir.setToolTipText("Pulse para Anadir");
		Anadir.addActionListener(this);
		Anadir.setPreferredSize(new Dimension(100, 25));
		rPanel.add(Anadir);
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Consultar" de servicios
	 */
	
	private void botonconsultar() {
		Consultar=new JButton("Consultar");
		Consultar.setToolTipText("Pulse para Consultar");
		Consultar.addActionListener(this);
		Consultar.setPreferredSize(new Dimension(60, 25));
		rPanel.add(Consultar);
	}
	
	/**
	 * Se encarga de los action listeners de los botones "Anadir", "Consultar", "Borrar" y "Buscar". 
	 * El bot�n "Anadir" se encargar� de crear el dialogo con los respectivos cambios para anadir correctamente el servicio.
	 * El bot�n "Consultar" se encargar� de crear un dialogo para modificar el servicio.
	 * El bot�n "Borrar" se encargar� de eliminar el servicio elegido.
	 * El bot�n "Buscar" se encargar� de buscar en la BBDD todos los registros con tipo introducido.
	 * Si ocurre alg�n error en la ejecuci�n, se lanza el mensaje de error: "No se ha encontrado ningun servicio con tipo "" " si se intenta buscar y "No se ha podido eliminar el servicio" si se intenta borrar.
	 * @param e ActionEvent 
	 */
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.Buscar) {
			
			String str=TipoServicioT.getText().trim();
			tLista<tServicio> lista;
			lista = this.controladorServicios.getfSP().ObtenerListaServicios(str);
			servicios = new tServicio[lista.getLista().size()];
			if(!lista.getLista().isEmpty()) {
				for(int i = 0; i<lista.getLista().size();i++) {
					servicios[i]= lista.getLista().get(i);
				}
				ListaServicios.setListData(servicios);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha encontrado ningun servicio con tipo: " + "\"" + str + "\"",  "",
						 JOptionPane.CANCEL_OPTION);
			}
			
		}
		else if(e.getSource() == this.Anadir) {
			
			estado=1;
			JDialog dialogS = new JDialog();
			JPanel contentPane =new JPanel();
			dialogS.setContentPane(contentPane);
			panelC = new PanelConsultaServicios(estado,  this.controladorServicios, this.ListaServicios);
			panelC.setVisible(true);
			
			dialogS.setLayout(new BorderLayout());
			dialogS.setVisible(true);
			dialogS.setBounds(0, 0, 490, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			dialogS.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			
		}else if(e.getSource() == this.Consultar) {
			
			estado=0;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			panelC = new  PanelConsultaServicios(estado, this.controladorServicios, this.ListaServicios);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 490, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			
			
		}else if(e.getSource() == this.Eliminar) {
			ListaServicios.repaint();
			tServicio servicioAEliminar;
			index = this.ListaServicios.getSelectedIndex();
		    servicioAEliminar =  this.controladorServicios.getfSP().ObtenerServicio(index+1);
			boolean eliminado = this.controladorServicios.getfSP().EliminarServicio(servicioAEliminar);
			//this.listModel.removeElement(servicioAEliminar);
			this.ListaServicios.repaint();
			if(eliminado) {
				panelC.restarCodigo();
				this.ListaServicios.repaint();
				JOptionPane.showMessageDialog(this,
						 "Se ha eliminado correctamente el servicio ", "",
						 JOptionPane.CANCEL_OPTION);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha podido eliminar el servicio ", "",
						 JOptionPane.CANCEL_OPTION);
			}
		}
	}
}