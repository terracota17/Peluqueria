package view.producto;

import fachadaSA.productos.IFachadaSubsProductos;

public class ControladorProductos {

	private IFachadaSubsProductos sfSP; 
	
	public ControladorProductos(IFachadaSubsProductos sfSP) {
		this.sfSP = sfSP;
	}
	
	/** 
	 * Get de sfSP
	 * 
	 * @return IFachadaSubsProductos
	 */
	public IFachadaSubsProductos getSfSP() {
		return sfSP;
	}

	/**
	 * Set de sfSP
	 * 
	 * @param sfSP
	 */
	public void setSfSP(IFachadaSubsProductos sfSP) {
		this.sfSP = sfSP;
	}
	
}
