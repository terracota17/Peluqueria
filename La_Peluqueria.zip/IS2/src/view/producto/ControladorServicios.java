package view.producto;

import fachadaSA.servicios.IFachadaSubsServicios;

public class ControladorServicios {
	
	private IFachadaSubsServicios fSP;
	
	public ControladorServicios( IFachadaSubsServicios fSP) {
		this.fSP =fSP; 
	}
	
	/** 
	 * Get de fSP
	 * 
	 * @return IFachadaSubsServicios
	 */
	public IFachadaSubsServicios getfSP() {
		return fSP;
	}

	/**
	 * Set de fSP
	 * 
	 * @param fSP
	 */
	public void setfSP(IFachadaSubsServicios fSP) {
		this.fSP = fSP;
	}
	
	
}

