package view.producto;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import clases.tCliente;
import clases.tProducto;

public class PanelConsultaProductos extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton Modificar;
	private JButton Volver;

	private JLabel Stock;
	private JLabel Precio;
	private JLabel Nombre;
	private JTextField StockT;
	private JTextField PrecioT;
	private JTextField NombreT;
	private int estado = -1;
	private JList<tProducto> listaProductos;
	private static Integer codigo = 1;
	private ControladorProductos controladorProductos;
	
	public PanelConsultaProductos(int estado, JList<tProducto> listaProductos, ControladorProductos controladorProductos) {
		this.listaProductos = listaProductos;
		this.controladorProductos =controladorProductos;
		this.estado = estado;
		init_gui();
	}
	/**
	 * Se crea el PanelConsultaProductos
	 */
	private void init_gui() {
		if(this.estado == 1) Modificar = new JButton("Anadir");
		else Modificar = new JButton("Modificar");

		Volver = new JButton("Volver");
		Volver.addActionListener(this);
		Stock = new JLabel("Stock");
		Precio = new JLabel("Precio");
		Nombre = new JLabel("Nombre");
	
		StockT = new JTextField("0");
		StockT.setPreferredSize(new Dimension(80, 25));
		
		PrecioT = new JTextField("0.0");
		PrecioT.setPreferredSize(new Dimension(80, 25));
		
		NombreT = new JTextField("nombre");
		NombreT.setPreferredSize(new Dimension(80, 25));
		
		Volver.setPreferredSize(new Dimension(90, 25));
		Modificar.setPreferredSize(new Dimension(90, 25));
		Modificar.addActionListener(this);
		JPanel panelVolverModificar = new JPanel();
		panelVolverModificar.setVisible(true);
		panelVolverModificar.add(Volver);
		panelVolverModificar.add(new JLabel(" "));
		panelVolverModificar.add(Modificar);
		JPanel panelBusqueda = new JPanel();
	
		panelBusqueda.setVisible(true);
		panelBusqueda.add(Nombre);
		panelBusqueda.add(NombreT);
		
		panelBusqueda.add(Precio);
		panelBusqueda.add(PrecioT);
		
		panelBusqueda.add(Stock);
		panelBusqueda.add(StockT);
		
	
		this.setLayout(new BorderLayout());
		this.add(panelBusqueda, BorderLayout.PAGE_START);
		this.add(panelVolverModificar, BorderLayout.PAGE_END);
	}
	/**
	 * Se encarga de los action listeners de los botones "Volver" y "Modificar", el boton "Volver" cerrar� el dialogo creado por el PanelMainProductos
	 * El bot�n "Modificar" se encargar� de modificar correctamente el producto
	 * Si alguno de los campos introducidos por el usuario son incorrectos, se lanz una excepcion avisando del problema.
	 * Adem�s si surge algun error durante la ejecuci�n , se lanza un mensaje de error : "No se ha podido modificar el producto" si se intenta modificar 
	 * y se lanza otro error: "No se ha podido anadir correctamente el usuario " si se ha tratado de anadir el producto de manera incorrecta.
	 * @param e ActionEvent
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.Volver) {
			//cerrar el dialogo
			Window w= SwingUtilities.getWindowAncestor(this);
			w.setVisible(false);
			
		}else if(e.getSource() == this.Modificar) {
			if(estado == 1) {
				//Anadir
				try {
					String nombre =  (!this.NombreT.getText().trim().equals("nombre") && !NombreT.getText().equals("")) ? NombreT.getText().trim(): "nombre" ;
					double  precio = (!this.PrecioT.getText().trim().equals("0.0") && !this.PrecioT.getText().equals(""))  ? Double.parseDouble(this.PrecioT.getText()):0.0;
					if(precio  == 0.0) throw new NumberFormatException("El precio no puede ser 0.0  ");
					Integer stock =(!this.StockT.getText().equals("0") && !this.StockT.getText().equals("")) ? Integer.valueOf(this.StockT.getText().trim()): 0;
					if(stock == 0) throw new NumberFormatException("Stock no puede ser 0 !!!");
					
					boolean anadido = this.controladorProductos.getSfSP().AnadirProducto(new tProducto(codigo, precio, stock, nombre));
					if(anadido) {
						codigo++;
						JOptionPane.showMessageDialog(null,
								 "Se ha anadido correctamente el Producto", "",
								 JOptionPane.CANCEL_OPTION);
						
					}else {
						JOptionPane.showMessageDialog(null,
								 "No se ha anadido correctamente el Producto", "",
								 JOptionPane.CANCEL_OPTION);
					}
				}catch(NumberFormatException ex) {
					JOptionPane.showMessageDialog(this,
							 ex.getMessage(),  "",
							 JOptionPane.CANCEL_OPTION);
					JOptionPane.showMessageDialog(null,
							 "No se ha anadido correctamente el Producto", "",
							 JOptionPane.CANCEL_OPTION);
				}
				
			}else {
				try {
					int index = this.listaProductos.getSelectedIndex();
					String nombre =  (!this.NombreT.getText().trim().equals("nombre") && !NombreT.getText().equals("")) ? NombreT.getText().trim(): "nombre" ;
					double  precio = (!this.PrecioT.getText().trim().equals("0.0") && !this.PrecioT.getText().equals(""))  ? Double.parseDouble(this.PrecioT.getText()):0.0;
					if(precio == 0.0) throw new NumberFormatException("El precio no puede ser 0.0  ");
					Integer stock =(!this.StockT.getText().equals("0") && !this.StockT.getText().equals("")) ? Integer.valueOf(this.StockT.getText().trim()): 0;
					if(stock == 0) throw new NumberFormatException("El stock del producto no puede ser 0 !!! ");
					
					boolean modificado = this.controladorProductos.getSfSP().ModificarProducto(new tProducto(index+1, precio, stock, nombre));
					if(modificado) {
						
						JOptionPane.showMessageDialog(null,
								 "Se ha modificado correctamente el Producto", "",
								 JOptionPane.CANCEL_OPTION);
						
					}
				}catch(NumberFormatException ex) {
					JOptionPane.showMessageDialog(this,
							 ex.getMessage(),  "",
							 JOptionPane.CANCEL_OPTION);
					JOptionPane.showMessageDialog(null,
							 "No se ha anadido correctamente el Producto", "",
							 JOptionPane.CANCEL_OPTION);
				}
				
			}
		
	}
	}
/**
 * Se resta el codigo del producto
 */
	public void restarCodigo() {
		this.codigo--;
		
	}

}
