package view.producto;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import clases.tProducto;
import clases.tServicio;

public class PanelConsultaServicios extends JPanel implements ActionListener{
	
	
	private static final long serialVersionUID = 1L;
	private JButton Modificar;
	private JButton Volver;
	
	private JLabel Precio;
	private JLabel Nombre;
	private JLabel Descripcion;
	private JLabel Tipo;
	
	private JTextField PrecioT;
	private JTextField NombreT;
	private JTextField DescripcionT;
	private JTextField TipoT;
	
	private JList<tServicio> listaServicios;
	private static Integer codigo = 1;
	private int estado = -1;
	private ControladorServicios controladorServicios;
	
	public PanelConsultaServicios(int estado, ControladorServicios controladorServicios,JList<tServicio> listaServicios) {
		this.estado = estado;
		this.controladorServicios = controladorServicios;
		this.listaServicios = listaServicios;
		init_gui();
	}
	
	/**
	 * Inicializa la gui, creando los botones y dem�s componentes
	 */
	
	private void init_gui() {
		if(this.estado == 1) Modificar = new JButton("Anadir");
		else Modificar = new JButton("Modificar");
		
		Volver = new JButton("Volver");
		Nombre = new JLabel("Nombre");

		Precio = new JLabel("Precio");
		Descripcion = new JLabel("Descripcion");
		Tipo = new JLabel("Tipo");
		
		
		NombreT = new JTextField("nombre");
		PrecioT = new JTextField("precio");
		DescripcionT = new JTextField("Descripcion");
		TipoT = new JTextField("tipo");
		
		Volver.setPreferredSize(new Dimension(90, 25));
		Volver.addActionListener(this);
		Modificar.setPreferredSize(new Dimension(90, 25));
		Modificar.addActionListener(this);
		JPanel panelVolverModificar = new JPanel();
		panelVolverModificar.setVisible(true);
		panelVolverModificar.add(Volver);
		panelVolverModificar.add(new JLabel(" "));
		panelVolverModificar.add(Modificar);
		JPanel panelBusqueda = new JPanel();
	
		panelBusqueda.setVisible(true);
	
		panelBusqueda.add(Nombre);
		panelBusqueda.add(NombreT);
		this.NombreT.setPreferredSize(new Dimension(60, 25));
		
		panelBusqueda.add(Precio);
		panelBusqueda.add(PrecioT);
		this.Precio.setVisible(true);
		this.PrecioT.setVisible(true);
		this.PrecioT.setPreferredSize(new Dimension(60, 25));
		
		panelBusqueda.add(Descripcion);
		panelBusqueda.add(DescripcionT);
		this.DescripcionT.setVisible(true);
		this.Descripcion.setVisible(true);
		this.DescripcionT.setPreferredSize(new Dimension(60, 25));
		
		panelBusqueda.add(Tipo);
		panelBusqueda.add(TipoT);
		
		this.Tipo.setVisible(true);
		this.TipoT.setVisible(true);
		this.TipoT.setPreferredSize(new Dimension(60, 25));
		
		this.setLayout(new BorderLayout());
		this.add(panelBusqueda, BorderLayout.PAGE_START);
		this.add(panelVolverModificar, BorderLayout.PAGE_END);
	}
	/**
	 * Se verifica cual es la acci�n ejecutada (presionar volver o modificar) y se 
	 * actua en consecuencia. Se lanza mensaje de error si el precio es 0.
	 * @param e accion ejecutada sobre el panel de citas
	 */
	@Override
	public void actionPerformed(ActionEvent e)  {
		if(e.getSource() == this.Volver) {
			//cerrrar el dialogo
			Window w= SwingUtilities.getWindowAncestor(this);
			w.setVisible(false);
			
		}else if(e.getSource() == this.Modificar) {
			if(estado==1) {
				//Anadir
				try {
					String nombre =  (!this.NombreT.getText().trim().equals("nombre") && !NombreT.getText().equals("")) ? NombreT.getText().trim():"nombre" ;
					Double  precio = (!this.PrecioT.getText().trim().equals("precio") && !PrecioT.getText().equals("") ) ? Double.parseDouble(this.PrecioT.getText()) : 0.0;
					if(precio == 0.0) throw new NumberFormatException();
					String descripcion = (!this.DescripcionT.getText().trim().equals("descripcion") && !DescripcionT.getText().equals("")) ? DescripcionT.getText().trim():"Descripcion" ;
					String tipo = (!this.TipoT.getText().trim().equals("tipo") && !TipoT.getText().equals("")) ? TipoT.getText().trim(): "tipo" ;
					boolean anadido = this.controladorServicios.getfSP().AnadirServicio(new tServicio(codigo, nombre, precio, descripcion, tipo));
					if(anadido) {
						codigo++;
						JOptionPane.showMessageDialog(null,
								 "Se ha anadido correctamente el Servicio", "",
								 JOptionPane.CANCEL_OPTION);
						
					}else {
						JOptionPane.showMessageDialog(null,
								 "No se ha anadido correctamente el Servicio", "",
								 JOptionPane.CANCEL_OPTION);
					}
				}catch(NumberFormatException ex) {
					JOptionPane.showMessageDialog(this,
							 "El precio no puede ser un texto o caracter: ",  "",
							 JOptionPane.CANCEL_OPTION);
				}
				
				
				
			}else {
				try {
					Integer index = this.listaServicios.getSelectedIndex();
					String nombre =  (!this.NombreT.getText().trim().equals("nombre") && !NombreT.getText().equals("")) ? NombreT.getText().trim():"nombre" ;
					Double  precio = (!this.PrecioT.getText().trim().equals("precio") && !PrecioT.getText().equals("") ) ? Double.parseDouble(this.PrecioT.getText()) : 0.0;
					if(precio == 0.0) throw new NumberFormatException();
					String descripcion = (!this.DescripcionT.getText().trim().equals("descripcion") && !DescripcionT.getText().equals("")) ? DescripcionT.getText().trim():"Descripcion" ;
					String tipo = (!this.TipoT.getText().trim().equals("tipo") && !TipoT.getText().equals("")) ? TipoT.getText().trim(): "tipo" ;
					
					boolean modificado = this.controladorServicios.getfSP().ModificarServicio(new tServicio(index+1, nombre, precio, descripcion, tipo));
					if(modificado) {
						JOptionPane.showMessageDialog(null,
								 "Se ha modificado correctamente el Servicio", "",
								 JOptionPane.CANCEL_OPTION);	
					}else {
						JOptionPane.showMessageDialog(null,
								 "No se ha modificado correctamente el Servicio", "",
								 JOptionPane.CANCEL_OPTION);	
					}
				}catch(NumberFormatException ex) {
					JOptionPane.showMessageDialog(this,
							 "El precio no puede ser un texto o caracter: ",  "",
							 JOptionPane.CANCEL_OPTION);
				}
				
			}
		
		}
	}
	/**
	 * resta uno al codigo del servicio.
	 */
	public void restarCodigo() {
		this.codigo--;
	}
	
}
