package view.producto;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import clases.tLista;
import clases.tProducto;

import view.producto.ControladorProductos;

public class PanelMainProductos extends JPanel implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int estado;
	private JButton Buscar;
	private JButton Anadir;
	private JButton Eliminar;
	private JButton Consultar;
	private JTextField TipoProductoT;
	private JList<tProducto> ListaProductos;
	private JPanel centerPanel;
    private JPanel rPanel;
    private DefaultListModel<tProducto> model;
	private PanelConsultaProductos panelC;
	private ControladorProductos controladorProductos;
	private tProducto products[];

	
	public PanelMainProductos(ControladorProductos controladorProductos) {
		this.controladorProductos = controladorProductos;
		init_gui();
	}
	/**
	 * Se crea el PanelMainProductos
	 */
	private void init_gui() {
		model = new DefaultListModel<tProducto>();
		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
		this.add(centerPanel,BorderLayout.CENTER);
		
		rPanel = new JPanel();
		rPanel.setLayout(new BoxLayout(rPanel, BoxLayout.Y_AXIS));
		this.add(rPanel,BorderLayout.EAST);

		buscadorNombre();
		listaUsuarios();
		botonBuscar();
		botonBorrar();
		botonAnadir();
		botonconsultar();
		this.setVisible(true);
	}
	/**
	 * Se inicializa y se crea el buscador de productos
	 */
	private void buscadorNombre() {
		TipoProductoT=new JTextField("Introduzca el tipo de producto");
		
		TipoProductoT.setBounds(300,0,400,300);
		TipoProductoT.addActionListener(this);
		centerPanel.add(TipoProductoT);
	}
	/**
	 * Se inicializa la lista de Productos y se anade al panel central de la GUI
	 */
	private void listaUsuarios() {
		ListaProductos= new JList<tProducto>();	
		ListaProductos.setPreferredSize(new Dimension(400, 400));
		centerPanel.add(ListaProductos);
		
	}
	/**
	 * Se inicializa y se crea el bot�n "Buscar"
	 */
	private void botonBuscar() {
		Buscar=new JButton("Buscar");
		Buscar.setToolTipText("Pulse para buscar");
		Buscar.addActionListener(this);
		rPanel.add(Buscar);
	}
	/**
	 * Se inicializa y se crea el bot�n "Borrar"
	 */
	private void botonBorrar() {
		Eliminar=new JButton("Borrar");
		Eliminar.setToolTipText("Pulse para buscar");
		Eliminar.addActionListener(this);
		rPanel.add(Eliminar);
	}
	
	/**
	 * Se inicializa y se crea el bot�n "Anadir"
	 */
	private void botonAnadir() {
		Anadir=new JButton("Anadir");
		Anadir.setToolTipText("Pulse para Anadir");
		Anadir.addActionListener(this);
		rPanel.add(Anadir);
	}
	/**
	 * Se inicializa y se crea el bot�n "Consultar"
	 */
	private void botonconsultar() {
		Consultar=new JButton("Consultar");
		Consultar.setToolTipText("Pulse para Consultar");
		Consultar.addActionListener(this);
		rPanel.add(Consultar);
	}
	/**
	 * Se encarga de los action performed de los botones "Anadir" ,"Consultar", "Buscar", "Borrar".
	 * El boton "Anadir" se encargar� de crear el dialogo con los respectivos cambios para anadir correctamente el producto
	 * El boton "Consultar" se encargar� de crear un dialogo para modificar el producto
	 * El boton "Buscar" se encargar� de buscar en la BBDD todos los registros con nombre introducido 
	 * El boton "Borrar" se encargar� de eliminar el producto elegido
	 * Se lanza un mensaje para informar de si ha habido errores durante la ejecuci�n de proyecto
	 * @param e ActionEvent
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.Anadir) {
			estado = 1;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			panelC = new PanelConsultaProductos(estado,this.ListaProductos, this.controladorProductos);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 490, 120);
			
			contentPane.add(panelC, BorderLayout.CENTER);
			dialogU.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			
		}else if(e.getSource() == this.Buscar) {
			this.ListaProductos.setBackground(Color.ORANGE);
			String str=this.TipoProductoT.getText().trim();
			tLista<tProducto> lista;
			lista = this.controladorProductos.getSfSP().ObtenListaProducto(str);
			products =new tProducto[lista.getLista().size()];
			if(!lista.getLista().isEmpty()) {
				for(int i = 0; i<lista.getLista().size();i++) {
					products[i]= lista.getLista().get(i);
				}
				this.ListaProductos.setListData(products);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha encontrado ningun producto con nombre:  "+ "\""+str+ "\"" , "",
						 JOptionPane.CANCEL_OPTION);
			}
							
		}else if(e.getSource() == this.Consultar) {
			estado=0;
			JDialog dialogU = new JDialog();
			JPanel contentPane =new JPanel();
			dialogU.setContentPane(contentPane);
			PanelConsultaProductos panelC = new PanelConsultaProductos(this.estado, this.ListaProductos, this.controladorProductos);
			panelC.setVisible(true);
			
			dialogU.setLayout(new BorderLayout());
			dialogU.setVisible(true);
			dialogU.setBounds(0, 0, 490, 120);
			contentPane.add(panelC, BorderLayout.CENTER);
			
		}else if(e.getSource() == this.Eliminar) {
			this.ListaProductos.repaint();
			tProducto productoAEliminar;
			int index = this.ListaProductos.getSelectedIndex();
			productoAEliminar = this.controladorProductos.getSfSP().ObtenProducto(index+1);
			boolean eliminado = this.controladorProductos.getSfSP().EliminarProducto(productoAEliminar);
			
			if(eliminado) {
				this.panelC.restarCodigo();
				this.model.removeElement(productoAEliminar);
				this.ListaProductos.repaint();
				JOptionPane.showMessageDialog(this,
						 "Se ha eliminado correctamente el producto ", "",
						 JOptionPane.CANCEL_OPTION);
			}else {
				JOptionPane.showMessageDialog(this,
						 "No se ha podido eliminar el producto ", "",
						 JOptionPane.CANCEL_OPTION);
			}
		}
	}
}
